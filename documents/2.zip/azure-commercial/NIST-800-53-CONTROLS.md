# NIST SP 800-53 Rev 5 -- Complete Control Catalog

Reference: [NIST SP 800-53 Revision 5](https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)

This document lists all 20 control families, every base control, and control enhancements.
Applicability baselines (Low/Moderate/High) are noted where standard. Azure implementation
guidance is included for controls that map to Azure-native services.

---

## Table of Contents

1. [AC -- Access Control](#ac----access-control)
2. [AT -- Awareness and Training](#at----awareness-and-training)
3. [AU -- Audit and Accountability](#au----audit-and-accountability)
4. [CA -- Assessment, Authorization, and Monitoring](#ca----assessment-authorization-and-monitoring)
5. [CM -- Configuration Management](#cm----configuration-management)
6. [CP -- Contingency Planning](#cp----contingency-planning)
7. [IA -- Identification and Authentication](#ia----identification-and-authentication)
8. [IR -- Incident Response](#ir----incident-response)
9. [MA -- Maintenance](#ma----maintenance)
10. [MP -- Media Protection](#mp----media-protection)
11. [PE -- Physical and Environmental Protection](#pe----physical-and-environmental-protection)
12. [PL -- Planning](#pl----planning)
13. [PM -- Program Management](#pm----program-management)
14. [PS -- Personnel Security](#ps----personnel-security)
15. [PT -- PII Processing and Transparency](#pt----pii-processing-and-transparency)
16. [RA -- Risk Assessment](#ra----risk-assessment)
17. [SA -- System and Services Acquisition](#sa----system-and-services-acquisition)
18. [SC -- System and Communications Protection](#sc----system-and-communications-protection)
19. [SI -- System and Information Integrity](#si----system-and-information-integrity)
20. [SR -- Supply Chain Risk Management](#sr----supply-chain-risk-management)

---

## Baseline Legend

| Symbol | Meaning |
|--------|---------|
| **L** | Low baseline |
| **M** | Moderate baseline |
| **H** | High baseline |
| -- | Not selected for any baseline (organizational or system-specific) |

---

## AC -- Access Control

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| AC-1 | Policy and Procedures | L | M | H | Develop, document, disseminate access control policy and procedures. | Documented in governance repo; enforced via Azure Policy. |
| AC-2 | Account Management | L | M | H | Manage system accounts: create, enable, modify, disable, remove. | Entra ID, PIM, Access Reviews, lifecycle workflows. |
| AC-2(1) | Automated System Account Management | | M | H | Automated mechanisms to support account management. | Entra ID lifecycle workflows, Logic Apps. |
| AC-2(2) | Automated Temporary and Emergency Account Management | | M | H | Automatically remove/disable temporary and emergency accounts. | Entra ID guest access reviews, time-bound group membership. |
| AC-2(3) | Disable Accounts | | M | H | Disable accounts when no longer required. | Entra ID Access Reviews with auto-remove. |
| AC-2(4) | Automated Audit Actions | | M | H | Automatically audit account creation, modification, enabling, disabling, removal. | Entra ID audit logs -> Log Analytics. |
| AC-2(5) | Inactivity Logout | | | H | Require logout after defined inactivity period. | Conditional Access session controls. |
| AC-2(6) | Dynamic Privilege Management | | | | Implement dynamic privilege management. | PIM just-in-time activation. |
| AC-2(7) | Privileged User Accounts | | | H | Establish and administer privileged user accounts in accordance with role-based access scheme. | PIM, custom RBAC roles, no standing access. |
| AC-2(8) | Dynamic Account Management | | | | Create, activate, manage, deactivate accounts dynamically. | Entra ID dynamic groups. |
| AC-2(9) | Restrictions on Use of Shared and Group Accounts | | | | Establish conditions for shared/group accounts. | Policy: no shared accounts; service principals with federated credentials. |
| AC-2(11) | Usage Conditions | | | H | Enforce usage conditions for system accounts. | Conditional Access terms of use. |
| AC-2(12) | Account Monitoring for Atypical Usage | | | H | Monitor accounts for atypical usage. | Entra ID Identity Protection, Sentinel UEBA. |
| AC-2(13) | Disable Accounts for High-Risk Individuals | | | H | Disable accounts of users posing significant risk. | Entra ID Identity Protection risk-based policies. |
| AC-3 | Access Enforcement | L | M | H | Enforce approved authorizations for logical access. | Azure RBAC, Conditional Access, resource locks. |
| AC-3(2) | Dual Authorization | | | | Require dual authorization for access. | PIM approval workflows. |
| AC-3(3) | Mandatory Access Control | | | | Enforce mandatory access control. | Azure RBAC deny assignments, Deployment Stack deny settings. |
| AC-3(4) | Discretionary Access Control | | | | Enforce discretionary access control. | Azure RBAC, resource-level permissions. |
| AC-3(7) | Role-Based Access Control | | | | Enforce role-based access control. | Azure RBAC built-in and custom roles. |
| AC-3(8) | Revocation of Access Authorizations | | | | Revoke access upon policy change. | PIM, Conditional Access, token revocation. |
| AC-3(9) | Controlled Release | | | | Control information release based on authorizations. | Azure Information Protection, DLP. |
| AC-3(10) | Audited Override of Access Control Mechanisms | | | | Employ an audited override capability. | Break-glass accounts with Sentinel alerts. |
| AC-3(11) | Restrict Access to Specific Information Types | | | | Restrict access to specific information types. | Sensitivity labels, Purview. |
| AC-3(12) | Assert and Enforce Application Access | | | | Require applications to assert identity and access attributes. | Managed identities, app registrations with verified publisher. |
| AC-3(13) | Attribute-Based Access Control | | | | Enforce attribute-based access control. | Azure ABAC conditions on role assignments. |
| AC-3(14) | Individual Access | | | | Enable authorized individuals to access information. | Entra ID, Conditional Access. |
| AC-3(15) | Discretionary and Mandatory Access Control | | | | Enforce both discretionary and mandatory access controls. | RBAC + deny assignments. |
| AC-4 | Information Flow Enforcement | | M | H | Enforce approved authorizations for controlling information flow. | Azure Firewall, NSG, ASG, Private Endpoints, Private Link. |
| AC-4(1) | Object Security and Privacy Attributes | | | | Use security/privacy attributes for information flow control. | Sensitivity labels, Azure Information Protection. |
| AC-4(2) | Processing Domains | | | | Use processing domains to enforce information flow. | Subscription isolation, VNet segmentation. |
| AC-4(3) | Dynamic Information Flow Control | | | | Enforce dynamic information flow control. | Azure Firewall threat intelligence, adaptive network hardening. |
| AC-4(4) | Flow Control of Encrypted Information | | | | Prevent encrypted information from bypassing flow control. | Azure Firewall TLS inspection (Premium). |
| AC-4(6) | Metadata | | | | Enforce information flow using metadata. | Azure Information Protection labels. |
| AC-4(8) | Security and Privacy Policy Filters | | | | Enforce information flow using security policy filters. | Azure Firewall application rules, WAF. |
| AC-4(12) | Data Type Identifiers | | | | Use data type identifiers to enforce information flow. | Purview data classification. |
| AC-4(14) | Security or Privacy Policy Filter Constraints | | | | Prevent implementation of filter constraints when degraded. | Azure Firewall forced-tunnel mode. |
| AC-4(21) | Physical or Logical Separation of Information Flows | | | | Separate information flows logically or physically. | VNet isolation, subscription boundaries, NSG. |
| AC-4(26) | Audit Filtering Actions | | | | Record and review content filtering actions. | Azure Firewall diagnostic logs -> Log Analytics. |
| AC-5 | Separation of Duties | | M | H | Separate duties of individuals to prevent conflicts. | RBAC custom roles, no single user with create+approve. |
| AC-6 | Least Privilege | | M | H | Employ least privilege principle. | PIM, scoped RBAC, no standing Owner. |
| AC-6(1) | Authorize Access to Security Functions | | M | H | Authorize access to security functions explicitly. | PIM eligible assignments for security roles. |
| AC-6(2) | Non-Privileged Access for Nonsecurity Functions | | M | H | Require non-privileged accounts for nonsecurity functions. | Separate admin and user accounts. |
| AC-6(3) | Network Access to Privileged Commands | | | H | Authorize network access to privileged commands. | Azure Bastion, JIT VM access. |
| AC-6(5) | Privileged Accounts | | M | H | Restrict privileged accounts to specific personnel/roles. | PIM, role-assignable groups. |
| AC-6(7) | Review of User Privileges | | | H | Review user privileges periodically. | Entra ID Access Reviews. |
| AC-6(9) | Log Use of Privileged Functions | | | H | Log the execution of privileged functions. | Entra ID audit logs, Activity Log. |
| AC-6(10) | Prohibit Non-Privileged Users from Executing Privileged Functions | | | H | Prevent non-privileged users from executing privileged functions. | RBAC enforcement, Azure Policy. |
| AC-7 | Unsuccessful Logon Attempts | L | M | H | Enforce limit on consecutive invalid logon attempts. | Entra ID Smart Lockout, risk-based Conditional Access. |
| AC-8 | System Use Notification | L | M | H | Display system use notification/banner before granting access. | Conditional Access terms of use, custom sign-in page. |
| AC-9 | Previous Logon Notification | | | | Notify user of previous logon. | Entra ID sign-in logs (user-accessible). |
| AC-10 | Concurrent Session Control | | | H | Limit the number of concurrent sessions. | Conditional Access session controls. |
| AC-11 | Device Lock | | M | H | Prevent access after period of inactivity via device lock. | Intune compliance policy, Conditional Access. |
| AC-11(1) | Pattern-Hiding Displays | | M | H | Conceal information previously on display. | Intune device configuration. |
| AC-12 | Session Termination | | M | H | Terminate user session after defined conditions. | Conditional Access session lifetime, token lifetime policies. |
| AC-12(1) | User-Initiated Logouts | | | | Provide logout capability for user-initiated sessions. | Application-level sign-out, Entra ID. |
| AC-14 | Permitted Actions Without Identification or Authentication | L | M | H | Identify actions permitted without identification/authentication. | Document in security plan. |
| AC-16 | Security and Privacy Attributes | | | | Support and maintain attribute-based access. | Azure ABAC, sensitivity labels, Purview. |
| AC-17 | Remote Access | L | M | H | Establish and document remote access. | Azure Bastion, VPN Gateway, Conditional Access. |
| AC-17(1) | Monitoring and Control | | M | H | Monitor and control remote access. | Azure Bastion audit logs, VPN diagnostics -> Log Analytics. |
| AC-17(2) | Protection of Confidentiality and Integrity Using Encryption | | M | H | Implement cryptographic mechanisms for remote access. | TLS 1.2+, IPsec VPN, ExpressRoute encryption. |
| AC-17(3) | Managed Access Control Points | | M | H | Route remote access through managed control points. | Azure Firewall, Application Gateway, Front Door. |
| AC-17(4) | Privileged Commands and Access | | M | H | Authorize and document privileged commands via remote access. | PIM + Azure Bastion, JIT VM access. |
| AC-18 | Wireless Access | L | M | H | Establish wireless access usage restrictions. | Not directly applicable in Azure IaaS; Intune for endpoints. |
| AC-18(1) | Authentication and Encryption | | M | H | Protect wireless access using authentication and encryption. | Intune Wi-Fi profiles, certificate-based auth. |
| AC-19 | Access Control for Mobile Devices | L | M | H | Establish usage restrictions for mobile devices. | Intune MDM/MAM, Conditional Access device compliance. |
| AC-19(5) | Full Device or Container-Based Encryption | | | | Employ full-device encryption on mobile devices. | Intune encryption compliance policy. |
| AC-20 | Use of External Systems | L | M | H | Establish terms for use of external systems. | Conditional Access: block unmanaged devices, B2B policies. |
| AC-20(1) | Limits on Authorized Use | | M | H | Permit use of external systems only as authorized. | Conditional Access named locations, compliant device requirement. |
| AC-20(2) | Portable Storage Devices -- Restricted Use | | M | H | Restrict use of portable storage on external systems. | Intune device restrictions, Defender for Endpoint. |
| AC-21 | Information Sharing | | M | H | Enable authorized information sharing and enforce restrictions. | Purview, sensitivity labels, B2B sharing policies. |
| AC-22 | Publicly Accessible Content | L | M | H | Designate individuals authorized to post publicly and review content. | Azure Policy deny public access, storage account public access settings. |
| AC-23 | Data Mining Protection | | | | Employ data mining prevention/detection. | Purview, SQL auditing, Defender for SQL. |
| AC-24 | Access Control Decisions | | | | Establish access control decisions. | Azure RBAC, Conditional Access. |
| AC-25 | Reference Monitor | | | | Implement reference monitor. | Azure Resource Manager, Entra ID. |

---

## AT -- Awareness and Training

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| AT-1 | Policy and Procedures | L | M | H | Develop, document, disseminate awareness and training policy. | Organizational policy document. |
| AT-2 | Literacy Training and Awareness | L | M | H | Provide security and privacy literacy training. | Organizational training program. |
| AT-2(1) | Practical Exercises | | | | Include practical exercises in literacy training. | Simulated phishing via Defender for Office 365. |
| AT-2(2) | Insider Threat | | M | H | Include insider threat awareness in training. | Organizational training. |
| AT-2(3) | Social Engineering and Mining | | | H | Include social engineering awareness. | Organizational training. |
| AT-3 | Role-Based Training | L | M | H | Provide role-based security training. | Training for Azure admins, security team. |
| AT-3(1) | Environmental Controls | | | | Provide training on environmental controls. | Cloud-specific training. |
| AT-3(2) | Physical Security Controls | | | | Provide training on physical security. | Azure datacenter responsibility (inherited). |
| AT-3(3) | Practical Exercises | | | | Include practical exercises in role-based training. | Tabletop exercises, red team exercises. |
| AT-4 | Training Records | L | M | H | Document and monitor training activities. | LMS records. |
| AT-5 | Contacts with Security Groups and Associations | | | | Establish contacts with security groups. | ISAC membership, MS Security Response Center. |
| AT-6 | Training Feedback | | | | Provide training feedback mechanisms. | Post-training surveys. |

---

## AU -- Audit and Accountability

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| AU-1 | Policy and Procedures | L | M | H | Develop audit and accountability policy. | Governance documentation. |
| AU-2 | Event Logging | L | M | H | Identify events to be logged. | Azure Diagnostic Settings, Activity Log. |
| AU-3 | Content of Audit Records | L | M | H | Audit records contain what, when, where, source, outcome, identity. | Azure resource logs (structured JSON), Activity Log. |
| AU-3(1) | Additional Audit Information | | M | H | Generate audit records with additional detail. | Diagnostic settings: all categories enabled. |
| AU-3(3) | Limit Personally Identifiable Information in Audit Logs | | | | Limit PII in audit logs. | Log Analytics data masking, Purview. |
| AU-4 | Audit Log Storage Capacity | L | M | H | Allocate audit log storage. | Log Analytics workspace capacity reservation, archive tier. |
| AU-4(1) | Transfer to Alternate Storage | | | | Transfer audit logs to alternate storage. | Export to Storage Account (immutable), Event Hub. |
| AU-5 | Response to Audit Logging Process Failures | L | M | H | Alert on audit processing failures and take actions. | Azure Monitor alerts on diagnostic setting failures. |
| AU-5(1) | Storage Capacity Warning | | | H | Warn when audit storage reaches threshold. | Log Analytics usage alerts. |
| AU-5(2) | Real-Time Alerts | | | H | Provide real-time alerting on audit events. | Sentinel real-time analytics rules. |
| AU-6 | Audit Record Review, Analysis, and Reporting | L | M | H | Review and analyze audit records. | Sentinel workbooks, KQL queries, scheduled analytics. |
| AU-6(1) | Automated Process Integration | | M | H | Integrate audit review using automated mechanisms. | Sentinel playbooks (Logic Apps). |
| AU-6(3) | Correlate Audit Record Repositories | | M | H | Correlate audit records across repositories. | Sentinel cross-workspace queries, data connectors. |
| AU-6(4) | Central Review and Analysis | | | H | Centralize audit review and analysis. | Central Log Analytics workspace. |
| AU-6(5) | Integrated Analysis of Audit Records | | | H | Integrate analysis of audit records with other data sources. | Sentinel UEBA, threat intelligence fusion. |
| AU-6(6) | Correlation with Physical Monitoring | | | H | Correlate audit with physical access monitoring. | Sentinel + physical access data integration. |
| AU-7 | Audit Record Reduction and Report Generation | | M | H | Provide audit reduction and report generation. | Log Analytics KQL, Sentinel workbooks, Power BI. |
| AU-7(1) | Automatic Processing | | M | H | Process audit records for events of interest. | Sentinel analytics rules, automated investigation. |
| AU-8 | Time Stamps | L | M | H | Use internal system clocks for timestamps in audit records. | Azure platform NTP (synchronized). |
| AU-8(1) | Synchronization with Authoritative Time Source | | | | Synchronize clocks with authoritative time source. | Azure NTP service (time.windows.com). |
| AU-9 | Protection of Audit Information | L | M | H | Protect audit information from unauthorized access/modification/deletion. | RBAC on Log Analytics, immutable storage for exports. |
| AU-9(2) | Store on Separate Physical Systems or Components | | | H | Store audit records on separate system/component. | Separate management subscription, dedicated storage account. |
| AU-9(3) | Cryptographic Protection | | | H | Implement cryptographic protection of audit information. | Storage SSE, Log Analytics CMK. |
| AU-9(4) | Access by Subset of Privileged Users | | M | H | Authorize access to audit info only by subset of privileged users. | RBAC: Log Analytics Reader role to auditors only. |
| AU-10 | Non-Repudiation | | | H | Provide irrefutable evidence of actions. | Entra ID sign-in logs, Activity Log with identity correlation. |
| AU-11 | Audit Record Retention | L | M | H | Retain audit records for defined period. | Log Analytics 365-day retention, archive to storage (7 years). |
| AU-11(1) | Long-Term Retrieval Capability | | | | Provide long-term retrieval capability. | Log Analytics archive tier, Storage Account lifecycle. |
| AU-12 | Audit Record Generation | L | M | H | Provide audit record generation capability at system components. | DeployIfNotExists diagnostic settings policy. |
| AU-12(1) | System-Wide and Time-Correlated Audit Trail | | | H | Compile system-wide audit trail from individual component records. | Central Log Analytics workspace, correlated via TimeGenerated. |
| AU-12(3) | Changes by Authorized Individuals | | | H | Allow changes to audit configuration by authorized individuals. | RBAC on diagnostic settings. |
| AU-13 | Monitoring for Information Disclosure | | | | Monitor for evidence of information disclosure. | Defender for Cloud, Sentinel threat intelligence. |
| AU-14 | Session Audit | | | | Enable session-level auditing. | Azure Bastion session recording, VM extensions. |
| AU-16 | Cross-Organizational Audit Logging | | | | Employ cross-organizational audit logging. | Azure Lighthouse, cross-tenant Log Analytics. |

---

## CA -- Assessment, Authorization, and Monitoring

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| CA-1 | Policy and Procedures | L | M | H | Develop assessment, authorization, and monitoring policy. | Governance documentation. |
| CA-2 | Control Assessments | L | M | H | Assess security/privacy controls. | Defender for Cloud regulatory compliance, Azure Policy compliance. |
| CA-2(1) | Independent Assessors | | M | H | Employ independent assessors. | Third-party audit engagement. |
| CA-2(2) | Specialized Assessments | | | H | Include specialized assessments (red team, penetration testing). | Penetration testing (permitted per Azure policy). |
| CA-2(3) | Leveraging Results from External Organizations | | | | Leverage assessment results from external organizations. | Azure compliance certifications (SOC, ISO). |
| CA-3 | Information Exchange | L | M | H | Approve and manage information exchange with other systems. | VNet peering agreements, B2B policies, API management. |
| CA-3(6) | Transfer Authorizations | | | | Employ transfer authorizations between connected systems. | Private endpoints, service endpoints, managed identities. |
| CA-5 | Plan of Action and Milestones | L | M | H | Develop and update POA&M for findings. | Defender for Cloud recommendations, Azure DevOps work items. |
| CA-6 | Authorization | L | M | H | Authorize the system for processing before operation. | ATO process documentation. |
| CA-7 | Continuous Monitoring | L | M | H | Develop a continuous monitoring strategy. | Defender for Cloud, Sentinel, Azure Monitor. |
| CA-7(1) | Independent Assessment | | | H | Employ independent assessors for continuous monitoring. | Third-party MSSP integration with Sentinel. |
| CA-7(4) | Risk Monitoring | | | | Monitor security and privacy risk on an ongoing basis. | Defender for Cloud secure score, risk-based alerts. |
| CA-8 | Penetration Testing | | | H | Conduct penetration testing. | Periodic pen tests (Azure pen test notification rules). |
| CA-8(1) | Independent Penetration Testing Agent or Team | | | | Employ independent penetration testing agent. | Third-party pen test provider. |
| CA-9 | Internal System Connections | L | M | H | Authorize and manage internal system connections. | VNet peering, private endpoints, service connections. |

---

## CM -- Configuration Management

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| CM-1 | Policy and Procedures | L | M | H | Develop configuration management policy. | Governance documentation. |
| CM-2 | Baseline Configuration | L | M | H | Develop, document, and maintain baseline configurations. | ARM/Bicep templates, Azure Policy guest configuration. |
| CM-2(2) | Automation Support for Accuracy and Currency | | M | H | Maintain baseline using automated mechanisms. | Deployment Stacks, Terraform state, Azure Automanage. |
| CM-2(3) | Retention of Previous Configurations | | M | H | Retain previous baseline configurations. | Git version control, Template Spec versions. |
| CM-2(7) | Configure Systems and Components for High-Risk Areas | | | H | Issue devices with restricted configurations for high-risk areas. | Intune compliance profiles. |
| CM-3 | Configuration Change Control | | M | H | Determine, document, approve, and audit configuration changes. | Azure DevOps change management, Activity Log, resource locks. |
| CM-3(1) | Automated Documentation, Notification, and Prohibition | | | H | Automate documentation and notification of changes. | Activity Log alerts, Sentinel analytics on resource changes. |
| CM-3(2) | Testing, Validation, and Documentation of Changes | | | H | Test, validate, and document changes before implementation. | Bicep what-if, staging environments, PR reviews. |
| CM-3(4) | Security and Privacy Representatives | | | | Include security representative in change control. | Required PR reviewers in Azure DevOps. |
| CM-3(6) | Cryptography Management | | | | Ensure cryptographic mechanisms are under configuration management. | Key Vault access policies, CMK rotation logs. |
| CM-4 | Impact Analyses | | M | H | Analyze changes for security and privacy impact. | Bicep what-if, Azure Policy compliance check. |
| CM-5 | Access Restrictions for Change | | M | H | Define and enforce access restrictions for changes. | RBAC: Contributor scoped, no direct prod changes without PIM. |
| CM-5(1) | Automated Access Enforcement and Audit Records | | | H | Enforce access restrictions and generate audit records. | RBAC + Activity Log. |
| CM-6 | Configuration Settings | L | M | H | Establish and enforce security configuration settings. | Azure Policy guest configuration, Azure Automanage. |
| CM-6(1) | Automated Management, Application, and Verification | | | H | Automate management and verification of configuration settings. | Azure Policy remediation tasks, DSC. |
| CM-6(2) | Respond to Unauthorized Changes | | | H | Alert/respond to unauthorized configuration changes. | Azure Policy non-compliance alerts, Sentinel. |
| CM-7 | Least Functionality | L | M | H | Configure systems to provide only essential capabilities. | Azure Policy allowed resource types, VM application control. |
| CM-7(1) | Periodic Review | | M | H | Review system periodically to identify unnecessary functions. | Azure Advisor, Resource Graph queries. |
| CM-7(2) | Prevent Program Execution | | M | H | Prevent execution of unauthorized software. | Defender for Cloud adaptive application controls. |
| CM-7(5) | Authorized Software -- Allow-by-Exception | | | H | Identify and allow only authorized software. | Application control policies (AppLocker/WDAC via Intune). |
| CM-8 | System Component Inventory | L | M | H | Develop and maintain system component inventory. | Azure Resource Graph, tags, Purview. |
| CM-8(1) | Updates During Installation and Removal | | M | H | Update inventory when components are installed/removed. | Azure Resource Graph (automatic). |
| CM-8(2) | Automated Maintenance | | | H | Maintain current, complete, accurate inventory automatically. | Resource Graph, Defender for Cloud asset inventory. |
| CM-8(3) | Automated Unauthorized Component Detection | | M | H | Detect unauthorized components automatically. | Azure Policy audit/deny, Defender for Cloud. |
| CM-8(4) | Accountability Information | | | | Include accountability info in component inventory. | Tags: Owner, CostCenter, Environment. |
| CM-9 | Configuration Management Plan | | M | H | Develop and implement a configuration management plan. | IaC repo structure, deployment pipelines, Template Specs. |
| CM-10 | Software Usage Restrictions | L | M | H | Use software in accordance with agreement restrictions. | License tracking, Azure Hybrid Benefit management. |
| CM-11 | User-Installed Software | L | M | H | Establish policies governing user-installed software. | Intune app management, Defender for Endpoint. |
| CM-12 | Information Location | | | | Identify and document information processing/storage locations. | Azure regions, data residency policies, Purview. |
| CM-13 | Data Action Mapping | | | | Develop mapping of data actions. | Purview data map. |
| CM-14 | Signed Components | | | | Prevent installation of unsigned components. | Secure Boot, code signing policies. |

---

## CP -- Contingency Planning

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| CP-1 | Policy and Procedures | L | M | H | Develop contingency planning policy. | Governance documentation. |
| CP-2 | Contingency Plan | L | M | H | Develop, maintain, and implement a contingency plan. | DR runbook, paired region strategy, failover procedures. |
| CP-2(1) | Coordinate with Related Plans | | M | H | Coordinate contingency plan with other plans. | Integrated incident response + DR plan. |
| CP-2(2) | Capacity Planning | | | H | Plan for capacity during contingency operations. | Azure reserved capacity, auto-scale rules. |
| CP-2(3) | Resume Mission-Essential Functions | | M | H | Plan for resumption of mission/business-essential functions. | RPO/RTO definitions, ASR replication. |
| CP-2(5) | Continue Mission-Essential Functions | | | H | Plan for continuance of essential functions with minimal disruption. | Active-active multi-region deployment. |
| CP-2(8) | Identify Critical Assets | | | H | Identify critical system assets supporting contingency. | Resource tagging (Criticality tag), CMDB. |
| CP-3 | Contingency Training | L | M | H | Provide contingency training. | DR drill schedule, tabletop exercises. |
| CP-3(1) | Simulated Events | | | H | Include simulated events in contingency training. | Annual DR failover test. |
| CP-4 | Contingency Plan Testing | L | M | H | Test the contingency plan. | ASR test failover, backup restore tests. |
| CP-4(1) | Coordinate with Related Plans | | M | H | Coordinate contingency plan testing with related plans. | Integrated DR/IR testing. |
| CP-4(2) | Alternate Processing Site | | | H | Test contingency plan at alternate processing site. | Failover to paired Azure region. |
| CP-6 | Alternate Storage Site | | M | H | Establish alternate storage site with protections equivalent to primary. | GRS/GZRS storage, cross-region backup vault. |
| CP-6(1) | Separation from Primary Site | | M | H | Separate alternate storage from primary to avoid same risk. | Azure paired regions (300+ mile separation). |
| CP-6(2) | Recovery Time and Recovery Point Objectives | | | H | Configure alternate storage to meet RTO/RPO. | ASR continuous replication, backup frequency. |
| CP-6(3) | Accessibility | | M | H | Identify potential accessibility problems to alternate site. | Azure region availability, cross-region networking. |
| CP-7 | Alternate Processing Site | | M | H | Establish alternate processing site. | Azure paired region, multi-region deployment. |
| CP-7(1) | Separation from Primary Site | | M | H | Separate alternate processing from primary site. | Azure paired regions. |
| CP-7(2) | Accessibility | | M | H | Identify potential accessibility problems. | Azure Traffic Manager, Front Door failover. |
| CP-7(3) | Priority of Service | | M | H | Develop SLAs with alternate processing site. | Azure SLAs, support plans. |
| CP-8 | Telecommunications Services | | M | H | Establish alternate telecommunications services. | ExpressRoute dual circuits, VPN failover. |
| CP-8(1) | Priority of Service Provisions | | M | H | Establish priority-of-service provisions for telecom. | ExpressRoute Premium, FastPath. |
| CP-8(2) | Single Points of Failure | | M | H | Obtain alternate telecom to reduce single points of failure. | Dual ExpressRoute from different providers. |
| CP-9 | System Backup | L | M | H | Conduct backups of system-level, user-level, and documentation. | Azure Backup: VMs, SQL, Files, Blobs. |
| CP-9(1) | Testing for Reliability and Integrity | | M | H | Test backup information for reliability and integrity. | Periodic restore tests, backup monitoring alerts. |
| CP-9(2) | Test Restoration Using Sampling | | | H | Use sampling to test restoration of selected functions. | Quarterly restore verification. |
| CP-9(3) | Separate Storage for Critical Information | | | H | Store backup copies at separate location. | GRS backup vault, cross-region replication. |
| CP-9(5) | Transfer to Alternate Storage Site | | | H | Transfer backup info to alternate storage site. | GRS automatic replication. |
| CP-9(8) | Cryptographic Protection | | | H | Implement cryptographic protection for backups. | Azure Backup encryption (platform-managed or CMK). |
| CP-10 | System Recovery and Reconstitution | L | M | H | Provide for recovery and reconstitution to known state. | ASR, Deployment Stacks (redeploy from IaC). |
| CP-10(2) | Transaction Recovery | | M | H | Implement transaction recovery for transaction-based systems. | SQL Always On, Cosmos DB multi-region writes. |
| CP-10(4) | Restore Within Time Period | | | H | Restore system within defined time period. | RTO targets enforced via ASR/backup policies. |
| CP-11 | Alternate Communications Protocols | | | | Provide alternate communications protocols. | VPN fallback for ExpressRoute. |
| CP-12 | Safe Mode | | | | Restrict operations when anomalous conditions detected. | Azure Firewall deny-all rule escalation. |
| CP-13 | Alternative Security Mechanisms | | | | Use alternative security mechanisms when primary is unavailable. | Break-glass accounts, backup MFA methods. |

---

## IA -- Identification and Authentication

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| IA-1 | Policy and Procedures | L | M | H | Develop identification and authentication policy. | Governance documentation. |
| IA-2 | Identification and Authentication (Organizational Users) | L | M | H | Uniquely identify and authenticate organizational users. | Entra ID, MFA. |
| IA-2(1) | Multi-Factor Authentication to Privileged Accounts | L | M | H | Implement MFA for privileged accounts. | Entra ID MFA + PIM. |
| IA-2(2) | Multi-Factor Authentication to Non-Privileged Accounts | L | M | H | Implement MFA for non-privileged accounts. | Entra ID MFA via Conditional Access (all users). |
| IA-2(5) | Individual Authentication with Group Authentication | | | | Require individual authentication when group auth is employed. | Named service principals per service, no shared credentials. |
| IA-2(6) | Access to Accounts -- Separate Device | | | H | Implement MFA via separate device. | FIDO2 security keys, Authenticator app on separate device. |
| IA-2(8) | Access to Accounts -- Replay Resistant | L | M | H | Implement replay-resistant authentication. | FIDO2, certificate-based auth, token binding. |
| IA-2(12) | Acceptance of PIV Credentials | | | | Accept PIV credentials. | Entra ID CBA (certificate-based authentication). |
| IA-3 | Device Identification and Authentication | | | H | Uniquely identify and authenticate devices. | Entra ID device registration, Intune compliance. |
| IA-4 | Identifier Management | L | M | H | Manage system identifiers. | Entra ID user/group lifecycle, managed identities. |
| IA-4(4) | Identify User Status | | | | Identify characteristics of individual status. | Entra ID user attributes, account enabled/disabled. |
| IA-5 | Authenticator Management | L | M | H | Manage system authenticators. | Entra ID password policies, SSPR, FIDO2 registration. |
| IA-5(1) | Password-Based Authentication | L | M | H | Enforce password complexity and management. | Entra ID password protection (banned passwords), SSPR. |
| IA-5(2) | Public Key-Based Authentication | | M | H | Implement PKI-based authentication. | Entra ID CBA, smart card auth. |
| IA-5(6) | Protection of Authenticators | | | | Protect authenticators commensurate with security category. | Key Vault for secrets, no secrets in code. |
| IA-5(7) | No Embedded Unencrypted Static Authenticators | | | | Ensure no unencrypted static authenticators embedded in applications. | Key Vault references, managed identities (no secrets). |
| IA-5(8) | Multiple System Accounts | | | | Implement controls for authenticators across multiple systems. | Entra ID SSO, federated credentials. |
| IA-5(13) | Expiration of Cached Authenticators | | | | Prohibit use of cached authenticators after defined period. | Conditional Access token lifetime, CAE. |
| IA-6 | Authentication Feedback | L | M | H | Obscure feedback of authentication information during authentication. | Entra ID sign-in page (masked password). |
| IA-7 | Cryptographic Module Authentication | L | M | H | Implement mechanisms for authentication to cryptographic module. | FIPS 140-2 validated modules, Key Vault HSM. |
| IA-8 | Identification and Authentication (Non-Organizational Users) | L | M | H | Uniquely identify and authenticate non-organizational users. | Entra ID B2B, external identities. |
| IA-8(1) | Acceptance of PIV Credentials from Other Agencies | L | M | H | Accept PIV credentials from other agencies. | Entra ID CBA cross-tenant. |
| IA-8(2) | Acceptance of External Authenticators | L | M | H | Accept only NIST-approved external authenticators. | B2B cross-tenant access policies, MFA trust. |
| IA-8(4) | Use of Defined Profiles | L | M | H | Conform to defined profiles for identity management. | SAML 2.0, OIDC, WS-Fed via Entra ID. |
| IA-9 | Service Identification and Authentication | | | | Identify and authenticate services. | Managed identities, service principal certificates. |
| IA-10 | Adaptive Authentication | | | | Employ adaptive authentication. | Entra ID Identity Protection, risk-based Conditional Access. |
| IA-11 | Re-Authentication | | | | Require re-authentication under defined circumstances. | Conditional Access sign-in frequency, step-up auth. |
| IA-12 | Identity Proofing | L | M | H | Identity proof users prior to account creation. | HR-driven provisioning, identity verification service. |
| IA-12(2) | Identity Evidence | | M | H | Require identity evidence for identity proofing. | Government-issued ID verification process. |
| IA-12(3) | Identity Evidence Validation and Verification | | M | H | Validate and verify identity evidence. | Entra Verified ID, third-party identity proofing. |
| IA-12(4) | In-Person Validation and Verification | | | H | Require in-person identity proofing. | Organizational process. |
| IA-12(5) | Address Confirmation | | M | H | Require registration code at validated address. | Organizational process. |
| IA-12(6) | Accept Externally-Proofed Identities | | | | Accept externally proofed identities. | Entra ID B2B, cross-tenant trust. |

---

## IR -- Incident Response

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| IR-1 | Policy and Procedures | L | M | H | Develop incident response policy. | Governance documentation. |
| IR-2 | Incident Response Training | L | M | H | Provide incident response training. | Annual IR training, tabletop exercises. |
| IR-2(1) | Simulated Events | | | H | Include simulated events in training. | Purple team exercises. |
| IR-2(2) | Automated Training Environments | | | H | Use automated mechanisms for training environments. | Sentinel simulation rules. |
| IR-3 | Incident Response Testing | | M | H | Test incident response capability. | Quarterly IR exercises. |
| IR-3(2) | Coordination with Related Plans | | M | H | Coordinate IR testing with related plans. | Integrated IR+DR testing. |
| IR-4 | Incident Handling | L | M | H | Implement incident handling capability. | Sentinel incidents, playbooks, investigation graph. |
| IR-4(1) | Automated Incident Handling Processes | | M | H | Automate incident handling. | Sentinel automation rules, Logic Apps playbooks. |
| IR-4(4) | Information Correlation | | | H | Correlate incident information across sources. | Sentinel data connectors, investigation graph. |
| IR-4(5) | Automatic Disabling of System | | | | Automatically disable system when a security violation is detected. | Conditional Access risk-based policies (block on high risk). |
| IR-4(6) | Insider Threats | | | | Implement incident handling for insider threats. | Purview Insider Risk Management. |
| IR-4(7) | Insider Threats -- Intra-Organization Coordination | | | | Coordinate insider threat handling across organization. | Insider Risk Management + HR integration. |
| IR-4(11) | Integrated Incident Response Team | | | | Establish integrated incident response team. | Sentinel SOAR + Teams integration. |
| IR-5 | Incident Monitoring | L | M | H | Track and document incidents. | Sentinel incident management, Azure DevOps integration. |
| IR-5(1) | Automated Tracking, Data Collection, and Analysis | | | H | Automate tracking and analysis. | Sentinel workbooks, hunting queries. |
| IR-6 | Incident Reporting | L | M | H | Require incident reporting to appropriate authorities. | Sentinel notification rules, email/Teams alerts. |
| IR-6(1) | Automated Reporting | | M | H | Automate incident reporting. | Sentinel playbooks -> ticketing system. |
| IR-6(3) | Supply Chain Coordination | | | H | Coordinate with supply chain on incidents. | Vendor communication plan. |
| IR-7 | Incident Response Assistance | L | M | H | Provide incident response support resource. | Security team on-call rotation, Sentinel documentation. |
| IR-7(1) | Automation Support for Availability of Information and Support | | M | H | Automate mechanisms to increase availability of IR support. | Sentinel wiki, playbook library, runbooks. |
| IR-7(2) | Coordination with External Providers | | | H | Establish relationships with external IR providers. | MSSP, Microsoft DART. |
| IR-8 | Incident Response Plan | L | M | H | Develop and maintain incident response plan. | IR plan document, updated annually. |
| IR-9 | Information Spillage Response | | | | Respond to information spillage. | Data loss investigation procedures, Purview. |
| IR-10 | Integrated Information Security Analysis Team | | | | Establish integrated security analysis team. | SOC team structure. |

---

## MA -- Maintenance

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| MA-1 | Policy and Procedures | L | M | H | Develop maintenance policy. | Governance documentation. |
| MA-2 | Controlled Maintenance | L | M | H | Schedule and perform maintenance; control maintenance tools. | Azure Update Management, maintenance windows. |
| MA-2(2) | Automated Maintenance Activities | | | H | Automate maintenance scheduling and alerting. | Azure Update Management, Automation runbooks. |
| MA-3 | Maintenance Tools | | M | H | Approve, control, and monitor maintenance tools. | Approved VM extensions list, Azure Policy. |
| MA-3(1) | Inspect Tools | | M | H | Inspect maintenance tools for improper modifications. | Extension hash verification. |
| MA-3(2) | Inspect Media | | M | H | Inspect media for malicious code before use. | Defender for Endpoint, antimalware scan. |
| MA-3(3) | Prevent Unauthorized Removal | | | H | Prevent unauthorized removal of maintenance equipment. | Azure resource locks, PIM for destructive operations. |
| MA-4 | Nonlocal Maintenance | L | M | H | Approve and monitor nonlocal maintenance. | Azure Bastion (no direct RDP/SSH), JIT VM access. |
| MA-4(1) | Logging and Review | | | | Log nonlocal maintenance sessions. | Bastion session logs -> Log Analytics. |
| MA-4(3) | Comparable Security and Sanitization | | | | Comparable security for nonlocal maintenance. | Managed workstations, Conditional Access device compliance. |
| MA-5 | Maintenance Personnel | L | M | H | Establish authorization process for maintenance personnel. | PIM, separate maintenance role, supervised access. |
| MA-5(1) | Individuals Without Appropriate Access | | | H | Implement procedures for maintenance by uncleared personnel. | Supervised Azure Bastion sessions. |
| MA-6 | Timely Maintenance | | M | H | Obtain maintenance support within defined time period. | Azure Support plans (Premier/Unified), SLA compliance. |

---

## MP -- Media Protection

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| MP-1 | Policy and Procedures | L | M | H | Develop media protection policy. | Governance documentation. |
| MP-2 | Media Access | L | M | H | Restrict access to digital and non-digital media. | Azure Storage RBAC, private endpoints, SAS token expiry. |
| MP-3 | Media Marking | | M | H | Mark media with distribution limitations. | Sensitivity labels (Microsoft Purview). |
| MP-4 | Media Storage | | M | H | Physically control and securely store media. | Azure datacenter responsibility (inherited) + encryption at rest. |
| MP-5 | Media Transport | | M | H | Protect and control media during transport. | Encryption in transit (TLS 1.2+), Azure Import/Export encryption. |
| MP-5(2) | Documentation of Activities | | | | Document media transport activities. | Azure Import/Export audit trail. |
| MP-6 | Media Sanitization | L | M | H | Sanitize media prior to disposal or reuse. | Azure datacenter responsibility (NIST 800-88 compliant wipe). |
| MP-6(1) | Review, Approve, Track, Document, and Verify | | | H | Review/approve/track/document/verify sanitization. | Azure datacenter processes (inherited). |
| MP-6(2) | Equipment Testing | | | H | Test sanitization equipment. | Azure datacenter responsibility. |
| MP-7 | Media Use | L | M | H | Restrict use of certain media types. | Intune device restrictions, Defender for Endpoint. |
| MP-7(1) | Prohibit Use Without Owner | | M | H | Prohibit use of portable storage without identifiable owner. | Endpoint DLP. |

---

## PE -- Physical and Environmental Protection

> **Note:** In Azure cloud, PE controls are primarily **inherited** from Microsoft's datacenter operations. Microsoft maintains SOC 2 Type II, ISO 27001, and FedRAMP authorizations covering physical security. Document inheritance in your SSP.

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| PE-1 | Policy and Procedures | L | M | H | Develop physical and environmental protection policy. | Inherited from Azure. |
| PE-2 | Physical Access Authorizations | L | M | H | Develop and maintain authorized personnel list. | Inherited from Azure. |
| PE-3 | Physical Access Control | L | M | H | Enforce physical access authorizations. | Inherited from Azure datacenter controls. |
| PE-3(1) | System Access | | | H | Enforce physical access to system in addition to facility. | Inherited (caged/locked racks). |
| PE-4 | Access Control for Transmission | | M | H | Control physical access to transmission medium. | Inherited (fiber in conduit). |
| PE-5 | Access Control for Output Devices | | M | H | Control physical access to output devices. | Inherited. |
| PE-6 | Monitoring Physical Access | L | M | H | Monitor physical access. | Inherited (24x7 video surveillance). |
| PE-6(1) | Intrusion Alarms and Surveillance Equipment | | M | H | Monitor alarms and equipment. | Inherited. |
| PE-6(4) | Monitoring Physical Access to Systems | | | H | Monitor physical access to system components. | Inherited. |
| PE-8 | Visitor Access Records | L | M | H | Maintain visitor access records. | Inherited. |
| PE-9 | Power Equipment and Cabling | | M | H | Protect power equipment and cabling. | Inherited. |
| PE-10 | Emergency Shutoff | | M | H | Provide emergency shutoff capability. | Inherited. |
| PE-11 | Emergency Power | | M | H | Provide emergency power (UPS). | Inherited (UPS + generators). |
| PE-11(1) | Alternate Power Supply -- Minimal Operational Capability | | | H | Provide alternate power for minimal capability. | Inherited. |
| PE-12 | Emergency Lighting | L | M | H | Employ emergency lighting. | Inherited. |
| PE-13 | Fire Protection | L | M | H | Employ fire detection and suppression. | Inherited. |
| PE-13(1) | Detection Systems -- Automatic Activation and Notification | | | H | Auto-activate fire systems with notification. | Inherited. |
| PE-13(2) | Suppression Systems -- Automatic Activation and Notification | | M | H | Auto-activate suppression with notification. | Inherited. |
| PE-14 | Environmental Controls | L | M | H | Maintain temperature and humidity controls. | Inherited. |
| PE-14(2) | Monitoring with Alarms and Notifications | | | H | Monitor with alarms/notifications. | Inherited. |
| PE-15 | Water Damage Protection | L | M | H | Protect from water damage. | Inherited. |
| PE-16 | Delivery and Removal | L | M | H | Authorize and control entry/exit of equipment. | Inherited. |
| PE-17 | Alternate Work Site | | M | H | Employ controls at alternate work sites. | Remote work: VPN + Conditional Access. |
| PE-18 | Location of System Components | | | H | Position components to minimize damage/eavesdropping. | Azure region selection, availability zones. |
| PE-23 | Facility Location | | | | Plan facility location for risk reduction. | Azure region selection based on compliance requirements. |

---

## PL -- Planning

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| PL-1 | Policy and Procedures | L | M | H | Develop planning policy. | Governance documentation. |
| PL-2 | System Security and Privacy Plans | L | M | H | Develop and maintain system security/privacy plans. | SSP documentation. |
| PL-2(3) | Plan and Coordinate with Other Organizational Entities | | | | Coordinate security plans across the organization. | Cross-team planning sessions. |
| PL-4 | Rules of Behavior | L | M | H | Establish rules of behavior for system access. | Acceptable use policy, Conditional Access terms of use. |
| PL-4(1) | Social Media and External Site/Application Usage Restrictions | | | | Include social media restrictions. | Policy documentation. |
| PL-7 | Concept of Operations | | | | Develop concept of operations. | Architecture design document. |
| PL-8 | Security and Privacy Architectures | | M | H | Develop security architecture for the system. | Azure landing zone architecture doc. |
| PL-9 | Central Management | | | | Centrally manage designated controls. | Azure Policy, Management Groups, central Log Analytics. |
| PL-10 | Baseline Selection | L | M | H | Select control baselines for the system. | NIST 800-53 baseline selection (this document). |
| PL-11 | Baseline Tailoring | L | M | H | Tailor control baselines as needed. | Document tailoring decisions. |

---

## PM -- Program Management

> **Note:** PM controls are organizational-level and do not map directly to Azure technical controls. Implementation is through governance processes.

| Control ID | Control Name | L | M | H | Description |
|-----------|-------------|---|---|---|-------------|
| PM-1 | Information Security Program Plan | -- | -- | -- | Develop an organization-wide information security program plan. |
| PM-2 | Information Security Program Leadership Role | -- | -- | -- | Appoint senior official for information security. |
| PM-3 | Information Security and Privacy Resources | -- | -- | -- | Ensure resources for information security program. |
| PM-4 | Plan of Action and Milestones Process | -- | -- | -- | Implement a POA&M process. |
| PM-5 | System Inventory | -- | -- | -- | Develop and maintain inventory of organizational systems. |
| PM-5(1) | Inventory of Personally Identifiable Information | -- | -- | -- | Establish PII inventory. |
| PM-6 | Measures of Performance | -- | -- | -- | Develop measures of performance for security program. |
| PM-7 | Enterprise Architecture | -- | -- | -- | Develop enterprise architecture considering security. |
| PM-8 | Critical Infrastructure Plan | -- | -- | -- | Address security of critical infrastructure. |
| PM-9 | Risk Management Strategy | -- | -- | -- | Develop organization-wide risk management strategy. |
| PM-10 | Authorization Process | -- | -- | -- | Manage the authorization process. |
| PM-11 | Mission and Business Process Definition | -- | -- | -- | Define mission and business processes with security context. |
| PM-12 | Insider Threat Program | -- | -- | -- | Implement an insider threat program. |
| PM-13 | Security and Privacy Workforce | -- | -- | -- | Establish a security and privacy workforce development program. |
| PM-14 | Testing, Training, and Monitoring | -- | -- | -- | Implement testing, training, and monitoring strategy. |
| PM-15 | Security and Privacy Groups and Associations | -- | -- | -- | Establish contact with security groups/associations. |
| PM-16 | Threat Awareness Program | -- | -- | -- | Implement a threat awareness program. |
| PM-17 | Protecting Controlled Unclassified Information on External Systems | -- | -- | -- | Establish policy for CUI on external systems. |
| PM-18 | Privacy Program Plan | -- | -- | -- | Develop a privacy program plan. |
| PM-19 | Privacy Program Leadership Role | -- | -- | -- | Appoint senior official for privacy. |
| PM-20 | Dissemination of Privacy Program Information | -- | -- | -- | Maintain public-facing privacy program information. |
| PM-21 | Accounting of Disclosures | -- | -- | -- | Develop accounting of disclosures procedures. |
| PM-22 | Personally Identifiable Information Quality Management | -- | -- | -- | Develop PII quality management processes. |
| PM-23 | Data Governance Body | -- | -- | -- | Establish a data governance body. |
| PM-24 | Data Integrity Board | -- | -- | -- | Establish a data integrity board. |
| PM-25 | Minimization of Personally Identifiable Information Used in Testing, Training, and Research | -- | -- | -- | Minimize use of PII in testing. |
| PM-26 | Complaint Management | -- | -- | -- | Implement a complaint management process. |
| PM-27 | Privacy Reporting | -- | -- | -- | Develop privacy reports. |
| PM-28 | Risk Framing | -- | -- | -- | Receive and consider threat information from risk framing. |
| PM-30 | Supply Chain Risk Management Strategy | -- | -- | -- | Develop supply chain risk management strategy. |
| PM-31 | Continuous Monitoring Strategy | -- | -- | -- | Develop organization-wide continuous monitoring strategy. |
| PM-32 | Purposing | -- | -- | -- | Analyze systems supporting mission processes. |

---

## PS -- Personnel Security

> **Note:** PS controls are organizational HR processes. Azure implementation is limited to technical enforcement of onboarding/offboarding.

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| PS-1 | Policy and Procedures | L | M | H | Develop personnel security policy. | HR policy documentation. |
| PS-2 | Position Risk Designation | L | M | H | Assign risk designation to positions. | Organizational process. |
| PS-3 | Personnel Screening | L | M | H | Screen individuals prior to system access. | Background check before Entra ID account creation. |
| PS-3(3) | Information Requiring Special Protective Measures | | | H | Ensure personnel with access to special info have additional screening. | Organizational process. |
| PS-4 | Personnel Termination | L | M | H | Upon termination, disable access and retrieve credentials. | Entra ID lifecycle: disable account, revoke sessions, wipe device. |
| PS-4(2) | Automated Actions | | | | Automate termination actions. | Entra ID lifecycle workflows triggered by HR system. |
| PS-5 | Personnel Transfer | L | M | H | Review and adjust access upon personnel transfer. | Entra ID Access Reviews, role reassignment. |
| PS-6 | Access Agreements | L | M | H | Require access agreements (NDA, AUP). | Conditional Access terms of use. |
| PS-7 | External Personnel Security | L | M | H | Establish personnel security requirements for third-party providers. | B2B access policies, vendor risk assessment. |
| PS-8 | Personnel Sanctions | L | M | H | Employ formal sanctions process. | Organizational HR process. |
| PS-9 | Position Descriptions | L | M | H | Incorporate security roles in position descriptions. | Organizational HR process. |

---

## PT -- PII Processing and Transparency

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| PT-1 | Policy and Procedures | L | M | H | Develop PII processing and transparency policy. | Privacy policy documentation. |
| PT-2 | Authority to Process Personally Identifiable Information | L | M | H | Determine and document authority to process PII. | Data processing agreements, Purview. |
| PT-3 | Personally Identifiable Information Processing Purposes | L | M | H | Identify and document purposes for PII processing. | Privacy impact assessment, Purview data catalog. |
| PT-4 | Consent | L | M | H | Implement consent mechanisms for PII processing. | Application-level consent, Entra ID consent framework. |
| PT-5 | Privacy Notice | L | M | H | Provide effective notice about PII processing. | Privacy notice in applications. |
| PT-5(1) | Just-In-Time Notice | | | | Provide just-in-time notice of PII processing. | Application UX design. |
| PT-5(2) | Privacy Act Statements | | | | Include Privacy Act statements in forms collecting PII. | Application UX design. |
| PT-6 | System of Records Notice | -- | -- | -- | Publish System of Records Notices where required. | Organizational process. |
| PT-7 | Specific Categories of Personally Identifiable Information | L | M | H | Apply processing conditions for specific PII categories. | Purview sensitivity labels, DLP policies. |
| PT-7(1) | Social Security Numbers | | | | Implement protections for SSNs. | Data masking, Purview, SQL dynamic data masking. |
| PT-7(2) | First Amendment Information | | | | Apply additional protections to First Amendment info. | Organizational policy. |
| PT-8 | Computer Matching Requirements | -- | -- | -- | Address statutory requirements for computer matching. | Organizational process. |

---

## RA -- Risk Assessment

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| RA-1 | Policy and Procedures | L | M | H | Develop risk assessment policy. | Governance documentation. |
| RA-2 | Security Categorization | L | M | H | Categorize system and information (FIPS 199). | System categorization document. |
| RA-3 | Risk Assessment | L | M | H | Conduct risk assessment. | Defender for Cloud secure score, risk assessment report. |
| RA-3(1) | Supply Chain Risk Assessment | | | | Assess supply chain risks. | Vendor risk assessment process. |
| RA-5 | Vulnerability Monitoring and Scanning | L | M | H | Monitor and scan for vulnerabilities. | Defender for Cloud, Defender for Servers (Qualys), SQL VA. |
| RA-5(2) | Update Vulnerabilities to Be Scanned | | M | H | Update vulnerability scanning signatures. | Automated by Defender for Cloud. |
| RA-5(4) | Discoverable Information | | | | Discover publicly available information about the system. | Defender External Attack Surface Management. |
| RA-5(5) | Privileged Access | | M | H | Implement privileged access for vulnerability scanning. | Defender for Cloud auto-provisioning with elevated permissions. |
| RA-5(6) | Automated Trend Analyses | | | | Compare vulnerability scan results over time. | Defender for Cloud trend analysis, Sentinel workbooks. |
| RA-5(8) | Review Historic Audit Logs | | | | Review historic audit logs for vulnerability exploitation. | Sentinel hunting queries. |
| RA-5(11) | Public Disclosure Program | | | | Establish public disclosure program. | security.txt, MSRC coordination. |
| RA-7 | Risk Response | L | M | H | Respond to assessment findings. | Remediation tasks in Defender for Cloud, POA&M. |
| RA-8 | Privacy Impact Assessments | -- | -- | -- | Conduct privacy impact assessments. | PIA process for systems processing PII. |
| RA-9 | Criticality Analysis | | | H | Identify critical system components. | Business impact analysis, resource tagging (Criticality). |

---

## SA -- System and Services Acquisition

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| SA-1 | Policy and Procedures | L | M | H | Develop system and services acquisition policy. | Governance documentation. |
| SA-2 | Allocation of Resources | L | M | H | Determine security requirements and allocate resources. | Budget for security tooling (Defender, Sentinel). |
| SA-3 | System Development Life Cycle | L | M | H | Manage system using SDLC that incorporates security. | Secure SDLC, DevSecOps pipeline. |
| SA-3(1) | Manage Preproduction Environment | | | | Manage preproduction environment for security. | Non-prod management group, separate subscriptions. |
| SA-3(2) | Use of Live or Operational Data | | | | Protect security when using live data in pre-production. | Data masking, synthetic data. |
| SA-4 | Acquisition Process | L | M | H | Include security requirements in acquisition process. | Azure Marketplace vetting, vendor security assessments. |
| SA-4(1) | Functional Properties of Controls | | M | H | Require description of security controls. | Vendor documentation requirements. |
| SA-4(2) | Design and Implementation Information for Controls | | M | H | Require design/implementation info. | Architecture reviews. |
| SA-4(5) | System, Component, and Service Configurations | | | H | Require configuration documentation. | Vendor configuration guides. |
| SA-4(9) | Functions, Ports, Protocols, and Services in Use | | M | H | Require identification of functions, ports, protocols. | Network documentation, NSG rules. |
| SA-4(10) | Use of Approved PIV Products | | | | Use PIV-approved products. | FIDO2 certified authenticators. |
| SA-5 | System Documentation | L | M | H | Obtain and maintain system documentation. | Architecture docs, runbooks in Git. |
| SA-8 | Security and Privacy Engineering Principles | | M | H | Apply security engineering principles. | Azure Well-Architected Framework, threat modeling. |
| SA-9 | External System Services | L | M | H | Require external service providers to comply with security requirements. | Service agreements, Azure compliance certifications. |
| SA-9(2) | Identification of Functions, Ports, Protocols, and Services | | | H | Identify external services functions/ports. | Azure service tags, documented firewall rules. |
| SA-10 | Developer Configuration Management | | M | H | Require developers to perform configuration management. | Git, PR reviews, branch protection. |
| SA-11 | Developer Testing and Evaluation | | M | H | Require developers to create and execute test plans. | SAST/DAST in CI/CD, SonarQube, dependency scanning. |
| SA-11(1) | Static Code Analysis | | | | Perform static code analysis. | GitHub Advanced Security, SonarQube. |
| SA-11(2) | Threat Modeling | | | | Conduct threat modeling. | Microsoft Threat Modeling Tool. |
| SA-15 | Development Process, Standards, and Tools | | | | Require developers to follow approved processes. | DevSecOps standards document. |
| SA-17 | Developer Security and Privacy Architecture and Design | | | | Require security architecture documentation. | Architecture decision records. |
| SA-22 | Unsupported System Components | L | M | H | Replace or mitigate unsupported components. | Azure Advisor EOL alerts, Defender recommendations. |

---

## SC -- System and Communications Protection

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| SC-1 | Policy and Procedures | L | M | H | Develop system and communications protection policy. | Governance documentation. |
| SC-2 | Separation of System and User Functionality | | M | H | Separate user functionality from system management. | Separate admin and user accounts, PIM. |
| SC-3 | Security Function Isolation | | | H | Isolate security functions from nonsecurity functions. | Dedicated security subscription, isolated management plane. |
| SC-4 | Information in Shared System Resources | | M | H | Prevent unauthorized information transfer via shared resources. | Azure tenant isolation, subscription boundaries. |
| SC-5 | Denial-of-Service Protection | L | M | H | Protect against or limit effects of denial-of-service. | Azure DDoS Protection Standard. |
| SC-5(1) | Restrict Internal Users | | | | Restrict ability of internal users to launch DoS. | NSG outbound rules, Azure Firewall. |
| SC-5(2) | Capacity, Bandwidth, and Redundancy | | | | Manage capacity to limit DoS effects. | Auto-scaling, CDN, load balancing. |
| SC-7 | Boundary Protection | L | M | H | Monitor and control communications at system boundary. | Azure Firewall, NSG, WAF, Front Door, Private Endpoints. |
| SC-7(3) | Access Points | | M | H | Limit number of external network connections. | Single hub VNet egress through Azure Firewall. |
| SC-7(4) | External Telecommunications Services | | M | H | Implement managed interface for each external telecom connection. | ExpressRoute with Azure Firewall. |
| SC-7(5) | Deny by Default -- Allow by Exception | | M | H | Deny network traffic by default, allow by exception. | NSG deny-all default, explicit allow rules. |
| SC-7(7) | Split Tunneling for Remote Devices | | M | H | Prevent split tunneling for remote devices. | Force-tunnel VPN configuration. |
| SC-7(8) | Route Traffic to Authenticated Proxy Servers | | M | H | Route traffic through authenticated proxy. | Azure Firewall explicit proxy. |
| SC-7(9) | Restrict Threatening Outgoing Communications Traffic | | | H | Detect and deny outgoing threat traffic. | Azure Firewall threat intelligence (Deny mode). |
| SC-7(10) | Prevent Exfiltration | | | H | Prevent unauthorized exfiltration. | Azure Firewall, DLP, private endpoints. |
| SC-7(11) | Restrict Incoming Communications Traffic | | | | Restrict incoming traffic to authorized sources. | NSG, Azure Firewall, WAF. |
| SC-7(14) | Protect Against Unauthorized Physical Connections | | | | Protect against unauthorized physical connections. | Inherited from Azure datacenter. |
| SC-7(18) | Fail Secure | | | H | Fail secure in event of boundary device failure. | Azure Firewall HA, NSG stateless fallback. |
| SC-7(20) | Dynamic Isolation and Segregation | | | | Dynamically isolate/segregate system components. | Micro-segmentation with ASG, NSG dynamic rules. |
| SC-7(21) | Isolation of System Components | | M | H | Employ boundary protection to isolate components. | Subnet isolation, private endpoints, VNet isolation. |
| SC-7(24) | Personally Identifiable Information | | | | Control transfer of PII across boundaries. | DLP policies, Purview. |
| SC-7(25) | Unclassified Telecommunications Systems -- Separate from External Networks | | | | Separate from external networks. | Private endpoints, no public access. |
| SC-7(29) | Separate Subnets to Isolate Functions | | | | Employ separate subnets for different functions. | Hub-spoke with functional subnets. |
| SC-8 | Transmission Confidentiality and Integrity | | M | H | Protect confidentiality and integrity of transmitted information. | TLS 1.2+, IPsec, ExpressRoute encryption. |
| SC-8(1) | Cryptographic Protection | | M | H | Implement cryptographic mechanisms for transmission protection. | TLS, HTTPS-only enforcement via Azure Policy. |
| SC-8(2) | Pre- and Post-Transmission Handling | | | | Maintain confidentiality/integrity during pre/post transmission. | End-to-end encryption. |
| SC-10 | Network Disconnect | | M | H | Terminate network connection at end of session or after inactivity. | Conditional Access session timeout, VPN idle timeout. |
| SC-12 | Cryptographic Key Establishment and Management | L | M | H | Establish and manage cryptographic keys. | Azure Key Vault, HSM-backed keys, key rotation policies. |
| SC-12(1) | Availability | | | H | Maintain availability of information in event of key loss. | Key Vault soft-delete + purge protection. |
| SC-12(2) | Symmetric Keys | | | | Produce, control, and distribute symmetric keys using NIST-approved methods. | Key Vault AES-256. |
| SC-12(3) | Asymmetric Keys | | | | Produce, control, and distribute asymmetric keys using NIST-approved methods. | Key Vault RSA-2048+, EC keys. |
| SC-12(6) | Physical Control of Keys | | | | Maintain physical control of keys. | Key Vault Managed HSM (FIPS 140-2 Level 3). |
| SC-13 | Cryptographic Protection | L | M | H | Determine required cryptographic uses and implement. | FIPS 140-2 validated modules (Azure default). |
| SC-15 | Collaborative Computing Devices and Applications | | M | H | Prohibit remote activation of collaborative devices. | Intune device restrictions. |
| SC-17 | Public Key Infrastructure Certificates | | M | H | Issue public key certificates or obtain from approved provider. | Azure managed certificates, App Service certificates. |
| SC-18 | Mobile Code | | M | H | Define and enforce mobile code restrictions. | Defender for Cloud adaptive application controls. |
| SC-20 | Secure Name/Address Resolution Service (Authoritative Source) | L | M | H | Provide secure DNS (DNSSEC or equivalent). | Azure DNS, Private DNS zones. |
| SC-21 | Secure Name/Address Resolution Service (Recursive or Caching Resolver) | L | M | H | Request and perform data origin authentication for name resolution. | Azure DNS Private Resolver. |
| SC-22 | Architecture and Provisioning for Name/Address Resolution Service | L | M | H | Ensure DNS is fault-tolerant and role-separated. | Azure DNS (geo-distributed, anycast). |
| SC-23 | Session Authenticity | | M | H | Protect session authenticity. | TLS session tickets, anti-replay, CSRF tokens. |
| SC-23(1) | Invalidate Session Identifiers at Logout | | | | Invalidate session identifiers at logout. | Entra ID token revocation. |
| SC-28 | Protection of Information at Rest | | M | H | Protect confidentiality and integrity of information at rest. | SSE, Azure Disk Encryption, SQL TDE, Storage encryption. |
| SC-28(1) | Cryptographic Protection | | M | H | Implement cryptographic protection for information at rest. | AES-256 encryption (platform-managed or CMK). |
| SC-28(3) | Cryptographic Keys | | | | Provide protected storage for cryptographic keys. | Key Vault, Managed HSM. |
| SC-39 | Process Isolation | L | M | H | Maintain separate execution domain for each process. | Azure platform isolation (hypervisor-level). |
| SC-45 | System Time Synchronization | | | | Synchronize system clocks. | Azure NTP service. |

---

## SI -- System and Information Integrity

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| SI-1 | Policy and Procedures | L | M | H | Develop system and information integrity policy. | Governance documentation. |
| SI-2 | Flaw Remediation | L | M | H | Identify, report, and correct system flaws. | Azure Update Management, Defender recommendations. |
| SI-2(1) | Central Management | | | | Centrally manage flaw remediation. | Defender for Cloud, Azure Update Management. |
| SI-2(2) | Automated Flaw Remediation Status | | M | H | Determine and report flaw remediation status automatically. | Defender for Cloud vulnerability assessment dashboard. |
| SI-2(3) | Time to Remediate Flaws and Benchmarks for Corrective Actions | | | | Establish benchmarks for corrective actions. | Defender for Cloud SLA for remediation. |
| SI-2(4) | Automated Patch Management Tools | | | H | Employ automated patch management. | Azure Update Management, auto-patching for Arc-enabled servers. |
| SI-2(5) | Automatic Software and Firmware Updates | | | | Install security-relevant updates automatically. | Azure auto-patching, VM guest patching. |
| SI-2(6) | Removal of Previous Versions of Software and Firmware | | | | Remove previous versions after update. | VM image management, golden image pipeline. |
| SI-3 | Malicious Code Protection | L | M | H | Implement malicious code protection. | Defender for Endpoint, Defender for Servers. |
| SI-3(1) | Central Management | | | | Centrally manage malicious code protection. | Defender for Cloud auto-provisioning. |
| SI-3(2) | Automatic Updates | | | | Automatically update malicious code mechanisms. | Defender for Endpoint automatic updates. |
| SI-3(4) | Updates Only by Privileged Users | | | | Restrict malicious code mechanism updates to privileged users. | RBAC on Defender configuration. |
| SI-3(10) | Malicious Code Analysis | | | | Perform analysis of malicious code. | Defender for Cloud file integrity monitoring. |
| SI-4 | System Monitoring | L | M | H | Monitor the system for attacks, unauthorized connections, and anomalies. | Microsoft Sentinel, Defender for Cloud, Azure Monitor. |
| SI-4(1) | System-Wide Intrusion Detection System | | | H | Connect and configure individual IDS into system-wide IDS. | Sentinel with all Defender connectors. |
| SI-4(2) | Automated Tools and Mechanisms for Real-Time Analysis | | M | H | Employ automated tools for real-time analysis. | Sentinel real-time analytics, Defender for Cloud alerts. |
| SI-4(4) | Inbound and Outbound Communications Traffic | | M | H | Analyze inbound and outbound traffic for anomalies. | Azure Firewall logs, NSG flow logs, Traffic Analytics. |
| SI-4(5) | System-Generated Alerts | | M | H | Alert when system-generated indications occur. | Azure Monitor alerts, Sentinel incidents. |
| SI-4(7) | Automated Response to Suspicious Events | | | | Automate response to suspicious events. | Sentinel playbooks, Defender for Cloud workflow automation. |
| SI-4(9) | Testing of Monitoring Tools and Mechanisms | | | | Test monitoring tools and mechanisms. | Sentinel detection testing, MITRE ATT&CK coverage. |
| SI-4(10) | Visibility of Encrypted Communications | | | | Provide visibility into encrypted communications. | Azure Firewall Premium TLS inspection. |
| SI-4(12) | Automated Organization-Generated Alerts | | | H | Alert on traffic that violates organizational policy. | Azure Firewall threat intelligence alerts. |
| SI-4(14) | Wireless Intrusion Detection | | | | Employ wireless intrusion detection. | Not applicable in Azure IaaS. |
| SI-4(16) | Correlate Monitoring Information | | | | Correlate information from monitoring tools. | Sentinel cross-resource correlation. |
| SI-4(20) | Privileged Users | | | H | Implement additional monitoring for privileged users. | PIM audit logs, Sentinel privileged user analytics. |
| SI-4(22) | Unauthorized Network Services | | | H | Detect unauthorized network services. | Azure Policy, Defender for Cloud. |
| SI-4(23) | Host-Based Devices | | | | Implement host-based monitoring. | Defender for Endpoint, Azure Monitor Agent. |
| SI-4(24) | Indicators of Compromise | | | | Discover and collect indicators of compromise. | Sentinel threat intelligence, Defender TI. |
| SI-5 | Security Alerts, Advisories, and Directives | L | M | H | Receive and disseminate security alerts. | Microsoft Security Response Center, Defender alerts. |
| SI-5(1) | Automated Alerts and Advisories | | | H | Automate security alert and advisory distribution. | Sentinel notification rules, email/Teams alerts. |
| SI-6 | Security and Privacy Function Verification | | | H | Verify correct operation of security functions. | Defender for Cloud recommendations, policy compliance. |
| SI-7 | Software, Firmware, and Information Integrity | | M | H | Employ integrity verification tools. | Defender for Cloud FIM, Secure Boot, code signing. |
| SI-7(1) | Integrity Checks | | M | H | Perform integrity checks at startup, restart, or on command. | Azure trusted launch, Secure Boot. |
| SI-7(2) | Automated Notifications of Integrity Violations | | | H | Automated notifications on integrity violations. | Defender for Cloud FIM alerts. |
| SI-7(5) | Automated Response to Integrity Violations | | | H | Automatically shut down or restart on integrity violation. | VM auto-remediation. |
| SI-7(7) | Integration of Detection and Response | | M | H | Incorporate detection of changes into incident response. | Sentinel analytics on FIM events. |
| SI-7(15) | Code Authentication | | | | Implement code authentication for software/firmware. | Trusted launch, code signing. |
| SI-8 | Spam Protection | | M | H | Employ spam protection mechanisms. | Exchange Online Protection, Defender for Office 365. |
| SI-8(1) | Central Management | | | | Centrally manage spam protection. | Microsoft 365 Defender portal. |
| SI-8(2) | Automatic Updates | | | | Automatically update spam protection. | EOP auto-updates. |
| SI-10 | Information Input Validation | | M | H | Check validity of information inputs. | Application-level input validation, WAF. |
| SI-11 | Error Handling | | M | H | Generate error messages that provide necessary info without revealing exploitable data. | Application-level error handling, custom error pages. |
| SI-12 | Information Management and Retention | L | M | H | Manage and retain information per applicable requirements. | Azure data lifecycle policies, retention labels. |
| SI-12(1) | Limit Personally Identifiable Information Elements | | | | Limit PII to elements in authority. | Purview, DLP. |
| SI-12(2) | Minimize Personally Identifiable Information in Testing, Training, and Research | | | | Use de-identified PII in testing. | Data masking, synthetic data. |
| SI-12(3) | Information Disposal | | | | Dispose of information per requirements. | Azure Storage lifecycle, secure delete. |
| SI-13 | Predictable Failure Prevention | | | | Protect against predictable system failures. | Azure Availability Sets, Availability Zones. |
| SI-16 | Memory Protection | | M | H | Implement memory protection mechanisms. | Azure VM security features, DEP, ASLR. |
| SI-18 | Personally Identifiable Information Quality Operations | -- | -- | -- | Implement PII quality operations. | Data quality processes. |
| SI-19 | De-Identification | -- | -- | -- | Remove PII elements from datasets. | Purview, SQL dynamic data masking. |
| SI-20 | Tainting | | | | Embed data tainting for information leakage detection. | Canary tokens, watermarking. |

---

## SR -- Supply Chain Risk Management

| Control ID | Control Name | L | M | H | Description | Azure Implementation |
|-----------|-------------|---|---|---|-------------|---------------------|
| SR-1 | Policy and Procedures | L | M | H | Develop supply chain risk management policy. | Governance documentation. |
| SR-2 | Supply Chain Risk Management Plan | L | M | H | Develop SCRM plan. | Vendor risk assessment framework. |
| SR-2(1) | Establish SCRM Team | L | M | H | Establish a SCRM team. | Cross-functional supply chain risk team. |
| SR-3 | Supply Chain Controls and Processes | L | M | H | Establish controls for the supply chain. | Vendor security requirements, SLA. |
| SR-5 | Acquisition Strategies, Tools, and Methods | L | M | H | Employ acquisition strategies to limit supply chain risk. | Azure Marketplace verification, approved vendor list. |
| SR-6 | Supplier Assessments and Reviews | | | H | Assess and review suppliers. | Vendor risk assessment, SOC 2 review. |
| SR-6(1) | Testing and Analysis | | | | Conduct testing and analysis of supply chain components. | Dependency scanning, SBOM analysis. |
| SR-8 | Notification Agreements | L | M | H | Establish notification agreements with supply chain partners. | Contractual notification requirements. |
| SR-9 | Tamper Resistance and Detection | | | | Implement tamper resistance/detection. | Trusted launch, Secure Boot, code signing. |
| SR-10 | Inspection of Systems or Components | | | H | Inspect systems/components upon delivery. | Image scanning, container image verification. |
| SR-11 | Component Authenticity | | M | H | Develop and implement anti-counterfeit policies. | Verified publisher for apps, container image signing. |
| SR-11(1) | Anti-Counterfeit Training | | | | Provide anti-counterfeit training. | Organizational training. |
| SR-11(2) | Configuration Control for Component Service and Repair | | | | Maintain configuration control for component service. | IaC version control, Template Spec versions. |
| SR-12 | Component Disposal | L | M | H | Dispose of system components per organizational policy. | Azure resource decommission process, resource locks. |

---

## Appendix: Control Family Summary

| Family | ID | Total Base Controls | Total w/ Enhancements |
|--------|----|--------------------|----------------------|
| Access Control | AC | 25 | 79 |
| Awareness and Training | AT | 6 | 11 |
| Audit and Accountability | AU | 16 | 36 |
| Assessment, Authorization, and Monitoring | CA | 9 | 16 |
| Configuration Management | CM | 14 | 35 |
| Contingency Planning | CP | 13 | 33 |
| Identification and Authentication | IA | 12 | 30 |
| Incident Response | IR | 10 | 22 |
| Maintenance | MA | 6 | 14 |
| Media Protection | MP | 7 | 12 |
| Physical and Environmental Protection | PE | 23 | 36 |
| Planning | PL | 11 | 13 |
| Program Management | PM | 32 | 33 |
| Personnel Security | PS | 9 | 11 |
| PII Processing and Transparency | PT | 8 | 11 |
| Risk Assessment | RA | 9 | 16 |
| System and Services Acquisition | SA | 22 | 42 |
| System and Communications Protection | SC | 51 | 89 |
| System and Information Integrity | SI | 23 | 51 |
| Supply Chain Risk Management | SR | 12 | 17 |

**Total: ~325 base controls, ~600+ with enhancements**

---

## References

- [NIST SP 800-53 Rev 5 (full publication)](https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)
- [NIST SP 800-53B Control Baselines](https://csrc.nist.gov/publications/detail/sp/800-53b/final)
- [Azure built-in policy initiative: NIST SP 800-53 Rev. 5](https://learn.microsoft.com/en-us/azure/governance/policy/samples/nist-sp-800-53-r5)
- [Microsoft Defender for Cloud Regulatory Compliance](https://learn.microsoft.com/en-us/azure/defender-for-cloud/update-regulatory-compliance-packages)
- [Azure compliance documentation](https://learn.microsoft.com/en-us/azure/compliance/)
