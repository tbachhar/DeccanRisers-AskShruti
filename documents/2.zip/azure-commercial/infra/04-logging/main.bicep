targetScope = 'resourceGroup'

@description('Azure region')
param location string = resourceGroup().location

@description('Log Analytics Workspace retention in days (NIST AU-11)')
param retentionInDays int = 365

@description('Subscription ID for the Management subscription')
param managementSubscriptionId string

// ============================================================
// Log Analytics Workspace
// NIST AU-3, AU-4, AU-6, AU-7, AU-11
// ============================================================
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'law-nist-central'
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: retentionInDays
    features: {
      enableLogAccessUsingOnlyResourcePermissions: true
    }
    publicNetworkAccessForIngestion: 'Enabled'
    publicNetworkAccessForQuery: 'Enabled'
  }
}

// ============================================================
// Microsoft Sentinel
// NIST IR-4, IR-5, SI-4
// ============================================================
resource sentinel 'Microsoft.OperationsManagement/solutions@2015-11-01-preview' = {
  name: 'SecurityInsights(${logAnalytics.name})'
  location: location
  plan: {
    name: 'SecurityInsights(${logAnalytics.name})'
    publisher: 'Microsoft'
    product: 'OMSGallery/SecurityInsights'
    promotionCode: ''
  }
  properties: {
    workspaceResourceId: logAnalytics.id
  }
}

// ============================================================
// Automation Account
// NIST SI-2 (patch management), CM-3 (change tracking)
// ============================================================
resource automationAccount 'Microsoft.Automation/automationAccounts@2023-11-01' = {
  name: 'aa-nist-mgmt'
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    sku: {
      name: 'Basic'
    }
  }
}

// Link Automation Account to Log Analytics
resource automationLink 'Microsoft.OperationalInsights/workspaces/linkedServices@2020-08-01' = {
  parent: logAnalytics
  name: 'Automation'
  properties: {
    resourceId: automationAccount.id
  }
}

// ============================================================
// Activity Log export to Log Analytics (subscription scope)
// NIST AU-3, AU-6
// Deploy separately at subscription scope; reference this workspace ID
// ============================================================

// ============================================================
// Outputs
// ============================================================
output logAnalyticsWorkspaceId string = logAnalytics.id
output logAnalyticsWorkspaceName string = logAnalytics.name
output automationAccountId string = automationAccount.id
