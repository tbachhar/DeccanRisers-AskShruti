targetScope = 'tenant'

@description('Prefix for all management group names')
param prefix string = 'corp'

@description('Top-level management group display name')
param topLevelMgName string = 'Corp'

// ---------- Top-level MG ----------
resource corpMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}'
  properties: {
    displayName: topLevelMgName
  }
}

// ---------- Platform ----------
resource platformMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-platform'
  properties: {
    displayName: 'Platform'
    details: {
      parent: {
        id: corpMg.id
      }
    }
  }
}

// ---------- Landing Zones ----------
resource landingZonesMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-landingzones'
  properties: {
    displayName: 'Landing Zones'
    details: {
      parent: {
        id: corpMg.id
      }
    }
  }
}

resource productionMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-landingzones-prod'
  properties: {
    displayName: 'Production'
    details: {
      parent: {
        id: landingZonesMg.id
      }
    }
  }
}

resource nonProductionMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-landingzones-nonprod'
  properties: {
    displayName: 'Non-Production'
    details: {
      parent: {
        id: landingZonesMg.id
      }
    }
  }
}

// ---------- Sandbox ----------
resource sandboxMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-sandbox'
  properties: {
    displayName: 'Sandbox'
    details: {
      parent: {
        id: corpMg.id
      }
    }
  }
}

// ---------- Decommissioned ----------
resource decommissionedMg 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: '${prefix}-decommissioned'
  properties: {
    displayName: 'Decommissioned'
    details: {
      parent: {
        id: corpMg.id
      }
    }
  }
}

// ---------- Outputs ----------
output corpMgId string = corpMg.id
output platformMgId string = platformMg.id
output landingZonesMgId string = landingZonesMg.id
output productionMgId string = productionMg.id
output nonProductionMgId string = nonProductionMg.id
output sandboxMgId string = sandboxMg.id
output decommissionedMgId string = decommissionedMg.id
