targetScope = 'managementGroup'

@description('Management Group ID to assign policies to (e.g., corp)')
param targetMgId string

// ============================================================
// NIST SP 800-53 Rev. 5 Built-in Policy Initiative Assignment
// Initiative ID: 179d1daa-458f-4e47-8086-2a68d0d6c38f
// ============================================================
resource nistInitiativeAssignment 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'nist-800-53-r5'
  properties: {
    displayName: 'NIST SP 800-53 Rev. 5'
    description: 'Assigns the built-in NIST SP 800-53 Rev. 5 regulatory compliance initiative to the Corp management group.'
    policyDefinitionId: '/providers/Microsoft.Authorization/policySetDefinitions/179d1daa-458f-4e47-8086-2a68d0d6c38f'
    enforcementMode: 'Default'
    parameters: {}
  }
  identity: {
    type: 'SystemAssigned'
  }
  location: 'eastus'
}

// ============================================================
// Custom Policy: Deny Public IP on NIC
// NIST SC-7: Boundary Protection
// ============================================================
resource denyPublicIpPolicy 'Microsoft.Authorization/policyDefinitions@2023-04-01' = {
  name: 'deny-public-ip-on-nic'
  properties: {
    displayName: 'Deny public IP addresses on network interfaces'
    description: 'NIST SC-7: Prevents public IP assignment on NICs to enforce boundary protection.'
    policyType: 'Custom'
    mode: 'All'
    metadata: {
      category: 'Network'
      nistControls: 'SC-7'
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Network/networkInterfaces'
          }
          {
            field: 'Microsoft.Network/networkInterfaces/ipconfigurations[*].publicIpAddress.id'
            exists: true
          }
        ]
      }
      then: {
        effect: 'Deny'
      }
    }
  }
}

resource denyPublicIpAssignment 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'deny-public-ip-nic'
  properties: {
    displayName: 'Deny Public IP on NIC'
    policyDefinitionId: denyPublicIpPolicy.id
    enforcementMode: 'Default'
  }
}

// ============================================================
// Custom Policy: Deny Storage without Private Endpoint
// NIST SC-7, SC-8
// ============================================================
resource denyStorageNoPrivateEndpoint 'Microsoft.Authorization/policyDefinitions@2023-04-01' = {
  name: 'deny-storage-no-pe'
  properties: {
    displayName: 'Deny storage accounts without private endpoints'
    description: 'NIST SC-7/SC-8: Storage accounts must use private endpoints.'
    policyType: 'Custom'
    mode: 'All'
    metadata: {
      category: 'Storage'
      nistControls: 'SC-7, SC-8'
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Storage/storageAccounts'
          }
          {
            field: 'Microsoft.Storage/storageAccounts/networkAcls.defaultAction'
            notEquals: 'Deny'
          }
        ]
      }
      then: {
        effect: 'Deny'
      }
    }
  }
}

resource denyStorageNoPrivateEndpointAssignment 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'deny-storage-no-pe'
  properties: {
    displayName: 'Deny Storage without Private Endpoint'
    policyDefinitionId: denyStorageNoPrivateEndpoint.id
    enforcementMode: 'Default'
  }
}

// ============================================================
// Custom Policy: Require Tags (Environment, Owner, CostCenter)
// NIST CM-8: Information System Component Inventory
// ============================================================
resource requireTagsPolicy 'Microsoft.Authorization/policyDefinitions@2023-04-01' = {
  name: 'require-mandatory-tags'
  properties: {
    displayName: 'Require mandatory tags on resource groups'
    description: 'NIST CM-8: All resource groups must have Environment, Owner, and CostCenter tags.'
    policyType: 'Custom'
    mode: 'All'
    metadata: {
      category: 'Tags'
      nistControls: 'CM-8'
    }
    parameters: {
      tagName: {
        type: 'String'
        metadata: {
          displayName: 'Tag Name'
          description: 'Name of the required tag'
        }
      }
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Resources/subscriptions/resourceGroups'
          }
          {
            field: '[concat(\'tags[\', parameters(\'tagName\'), \']\')]'
            exists: false
          }
        ]
      }
      then: {
        effect: 'Deny'
      }
    }
  }
}

// Assign for each required tag
resource requireTagEnvironment 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'require-tag-environment'
  properties: {
    displayName: 'Require Environment tag'
    policyDefinitionId: requireTagsPolicy.id
    enforcementMode: 'Default'
    parameters: {
      tagName: {
        value: 'Environment'
      }
    }
  }
}

resource requireTagOwner 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'require-tag-owner'
  properties: {
    displayName: 'Require Owner tag'
    policyDefinitionId: requireTagsPolicy.id
    enforcementMode: 'Default'
    parameters: {
      tagName: {
        value: 'Owner'
      }
    }
  }
}

resource requireTagCostCenter 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'require-tag-costcenter'
  properties: {
    displayName: 'Require CostCenter tag'
    policyDefinitionId: requireTagsPolicy.id
    enforcementMode: 'Default'
    parameters: {
      tagName: {
        value: 'CostCenter'
      }
    }
  }
}

// ============================================================
// Custom Policy: Deny unmanaged disks
// NIST SC-28: Protection of Information at Rest
// ============================================================
resource denyUnmanagedDisks 'Microsoft.Authorization/policyDefinitions@2023-04-01' = {
  name: 'deny-unmanaged-disks'
  properties: {
    displayName: 'Deny virtual machines with unmanaged disks'
    description: 'NIST SC-28: VMs must use managed disks for encryption at rest.'
    policyType: 'Custom'
    mode: 'All'
    metadata: {
      category: 'Compute'
      nistControls: 'SC-28'
    }
    policyRule: {
      if: {
        allOf: [
          {
            field: 'type'
            equals: 'Microsoft.Compute/virtualMachines'
          }
          {
            field: 'Microsoft.Compute/virtualMachines/osDisk.uri'
            exists: true
          }
        ]
      }
      then: {
        effect: 'Deny'
      }
    }
  }
}

resource denyUnmanagedDisksAssignment 'Microsoft.Authorization/policyAssignments@2024-04-01' = {
  name: 'deny-unmanaged-disks'
  properties: {
    displayName: 'Deny Unmanaged Disks'
    policyDefinitionId: denyUnmanagedDisks.id
    enforcementMode: 'Default'
  }
}

// ============================================================
// Outputs
// ============================================================
output nistInitiativeAssignmentId string = nistInitiativeAssignment.id
