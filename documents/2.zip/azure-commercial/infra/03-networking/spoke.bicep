targetScope = 'resourceGroup'

@description('Azure region')
param location string = resourceGroup().location

@description('Hub VNet resource ID for peering')
param hubVnetId string

@description('Spoke VNet address prefix')
param spokeAddressPrefix string

@description('Spoke name identifier')
param spokeName string

@description('Route table ID (default route to firewall)')
param spokeRouteTableId string

@description('DDoS Protection Plan ID')
param ddosPlanId string

@description('Log Analytics Workspace ID for diagnostics')
param logAnalyticsWorkspaceId string

// ============================================================
// Spoke VNet
// ============================================================
resource spokeVnet 'Microsoft.Network/virtualNetworks@2023-09-01' = {
  name: 'vnet-spoke-${spokeName}'
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [spokeAddressPrefix]
    }
    ddosProtectionPlan: {
      id: ddosPlanId
    }
    enableDdosProtection: true
    subnets: [
      {
        name: 'snet-${spokeName}-app'
        properties: {
          addressPrefix: cidrSubnet(spokeAddressPrefix, 24, 0)
          routeTable: {
            id: spokeRouteTableId
          }
          networkSecurityGroup: {
            id: nsgDefault.id
          }
        }
      }
      {
        name: 'snet-${spokeName}-data'
        properties: {
          addressPrefix: cidrSubnet(spokeAddressPrefix, 24, 1)
          routeTable: {
            id: spokeRouteTableId
          }
          networkSecurityGroup: {
            id: nsgDefault.id
          }
        }
      }
      {
        name: 'snet-${spokeName}-infra'
        properties: {
          addressPrefix: cidrSubnet(spokeAddressPrefix, 24, 2)
          routeTable: {
            id: spokeRouteTableId
          }
          networkSecurityGroup: {
            id: nsgDefault.id
          }
        }
      }
    ]
  }
}

// ============================================================
// NSG -- Deny-all baseline
// NIST SC-7: Boundary Protection
// ============================================================
resource nsgDefault 'Microsoft.Network/networkSecurityGroups@2023-09-01' = {
  name: 'nsg-${spokeName}-default'
  location: location
  properties: {
    securityRules: [
      {
        name: 'DenyAllInbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// ============================================================
// VNet Peering: Spoke -> Hub
// ============================================================
resource spokeToHub 'Microsoft.Network/virtualNetworks/virtualNetworkPeerings@2023-09-01' = {
  parent: spokeVnet
  name: 'peer-${spokeName}-to-hub'
  properties: {
    remoteVirtualNetwork: {
      id: hubVnetId
    }
    allowVirtualNetworkAccess: true
    allowForwardedTraffic: true
    allowGatewayTransit: false
    useRemoteGateways: true
  }
}

// ============================================================
// NSG Flow Logs
// NIST AU-3, AU-12, SC-7
// ============================================================
resource nsgFlowLog 'Microsoft.Network/networkWatchers/flowLogs@2023-09-01' = {
  name: 'NetworkWatcher_${location}/flowlog-${spokeName}'
  location: location
  properties: {
    targetResourceId: nsgDefault.id
    storageId: '' // Replace with storage account ID for flow logs
    enabled: true
    retentionPolicy: {
      days: 365
      enabled: true
    }
    format: {
      type: 'JSON'
      version: 2
    }
    flowAnalyticsConfiguration: {
      networkWatcherFlowAnalyticsConfiguration: {
        enabled: true
        workspaceResourceId: logAnalyticsWorkspaceId
        trafficAnalyticsInterval: 10
      }
    }
  }
}

// ============================================================
// Diagnostic Settings
// ============================================================
resource spokeDiag 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-vnet-${spokeName}'
  scope: spokeVnet
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

output spokeVnetId string = spokeVnet.id
