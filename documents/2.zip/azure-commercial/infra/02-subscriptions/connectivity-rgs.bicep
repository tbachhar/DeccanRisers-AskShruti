targetScope = 'subscription'

@description('Azure region for resource group metadata')
param location string = 'eastus'

param commonTags object = {
  Environment: 'Platform'
  ManagedBy: 'Network-Team'
  Compliance: 'NIST-800-53'
}

// ============================================================
// Connectivity Subscription Resource Groups
// ============================================================

resource rgHub 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-conn-hub'
  location: location
  tags: union(commonTags, { Component: 'HubNetwork' })
}

resource rgFirewall 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-conn-firewall'
  location: location
  tags: union(commonTags, { Component: 'Firewall' })
}

resource rgDns 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-conn-dns'
  location: location
  tags: union(commonTags, { Component: 'DNS' })
}

resource rgGateway 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-conn-gateway'
  location: location
  tags: union(commonTags, { Component: 'VPNGateway' })
}
