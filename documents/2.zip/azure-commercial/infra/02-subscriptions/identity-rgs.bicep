targetScope = 'subscription'

@description('Azure region for resource group metadata')
param location string = 'eastus'

@description('Tags applied to all resource groups')
param commonTags object = {
  Environment: 'Platform'
  ManagedBy: 'Platform-Team'
  Compliance: 'NIST-800-53'
}

// ============================================================
// Identity Subscription Resource Groups
// Deploy this file against the Identity subscription
// ============================================================

resource rgIdentityAdds 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-identity-adds'
  location: location
  tags: union(commonTags, { Component: 'ActiveDirectory' })
}

resource rgIdentityPki 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-identity-pki'
  location: location
  tags: union(commonTags, { Component: 'PKI' })
}
