targetScope = 'subscription'

@description('Azure region for resource group metadata')
param location string = 'eastus'

param commonTags object = {
  Environment: 'Platform'
  ManagedBy: 'Platform-Team'
  Compliance: 'NIST-800-53'
}

// ============================================================
// Management Subscription Resource Groups
// ============================================================

resource rgLogging 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-mgmt-logging'
  location: location
  tags: union(commonTags, { Component: 'Logging' })
}

resource rgAutomation 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-mgmt-automation'
  location: location
  tags: union(commonTags, { Component: 'Automation' })
}

resource rgSentinel 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: 'rg-mgmt-sentinel'
  location: location
  tags: union(commonTags, { Component: 'Sentinel' })
}
