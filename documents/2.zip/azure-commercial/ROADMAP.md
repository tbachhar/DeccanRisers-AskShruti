# Azure Commercial Tenant -- NIST 800-53 Foundation Roadmap

## Status

Azure Blueprints (Preview) is deprecated July 11, 2026. This roadmap uses the
recommended replacement: **Template Specs + Deployment Stacks with Bicep**.

NIST 800-53 Rev 4/Rev 5 control families are mapped to Azure Policy initiatives
and enforced via Deployment Stacks at management group scope.

---

## Architecture Overview

```
Tenant Root Group
  |
  +-- Corp (Management Group)
  |     +-- Platform (MG)
  |     |     +-- Identity (Subscription)        -- AD DS, Entra ID Connect, PKI
  |     |     +-- Management (Subscription)       -- Log Analytics, Automation, Sentinel
  |     |     +-- Connectivity (Subscription)     -- Hub VNet, Firewall, ExpressRoute/VPN, DNS
  |     |
  |     +-- LandingZones (MG)
  |     |     +-- Production (MG)
  |     |     |     +-- Prod-Workload-001 (Sub)
  |     |     +-- Non-Production (MG)
  |     |           +-- Dev-Workload-001 (Sub)
  |     |
  |     +-- Sandbox (MG)
  |           +-- Sandbox-001 (Subscription)
  |
  +-- Decommissioned (MG)
```

---

## Phase 0 -- Prerequisites

| Step | Action | Owner |
|------|--------|-------|
| 0.1  | Enable Entra ID P2 license | IAM Team |
| 0.2  | Create break-glass accounts (2), exclude from Conditional Access | IAM Team |
| 0.3  | Enable MFA for all users (AC-7, IA-2, IA-5) | IAM Team |
| 0.4  | Register `Microsoft.Blueprint`, `Microsoft.PolicyInsights`, `Microsoft.Security` resource providers | Platform Team |
| 0.5  | Install Az CLI, Bicep CLI, Az PowerShell module | Platform Team |
| 0.6  | Create Azure DevOps / GitHub repo for IaC (`azure-commercial-iac`) | Platform Team |
| 0.7  | Assign `Owner` on Tenant Root Group to deployment SPN | Platform Team |

---

## Phase 1 -- Management Group Hierarchy

Deploy: `infra/01-management-groups/main.bicep`

Creates the hierarchy shown above. All subsequent policy and RBAC assignments
inherit downward.

NIST controls addressed: **AC-1, AC-2, AU-1, PM-9** (organizational governance structure).

```
az deployment tenant create \
  --location eastus \
  --template-file infra/01-management-groups/main.bicep
```

---

## Phase 2 -- Platform Subscriptions + Resource Groups

Deploy: `infra/02-subscriptions/main.bicep`

| Subscription | Resource Groups | Purpose |
|---|---|---|
| **Identity** | `rg-identity-adds`, `rg-identity-pki` | Domain controllers, certificate services |
| **Management** | `rg-mgmt-logging`, `rg-mgmt-automation`, `rg-mgmt-sentinel` | Central logging (AU-6, AU-7, SI-4), automation, SIEM |
| **Connectivity** | `rg-conn-hub`, `rg-conn-firewall`, `rg-conn-dns`, `rg-conn-gateway` | Hub network, Azure Firewall, Private DNS, VPN/ER GW |

---

## Phase 3 -- Hub-Spoke Networking (Connectivity Subscription)

Deploy: `infra/03-networking/main.bicep`

### 3.1 Hub VNet (`10.0.0.0/16`)

| Subnet | CIDR | Purpose |
|--------|------|---------|
| AzureFirewallSubnet | 10.0.0.0/24 | Azure Firewall |
| GatewaySubnet | 10.0.1.0/24 | VPN / ExpressRoute Gateway |
| AzureBastionSubnet | 10.0.2.0/24 | Azure Bastion (AC-17, SC-7) |
| dns-inbound | 10.0.3.0/24 | DNS Private Resolver inbound |
| dns-outbound | 10.0.4.0/24 | DNS Private Resolver outbound |

### 3.2 Spoke VNets (per landing zone subscription)

- Production spoke: `10.1.0.0/16`
- Dev spoke: `10.2.0.0/16`
- Peered to Hub VNet
- Route table: `0.0.0.0/0 -> Azure Firewall private IP`

### 3.3 NSG Baseline (per subnet)

- Deny all inbound by default
- Allow only required ports per workload
- NSG flow logs -> Log Analytics workspace (AU-3, AU-12, SC-7)

### 3.4 Azure Firewall (SC-7, AC-4)

- Threat intelligence: Alert and Deny
- Application rules: outbound allow-list only
- Network rules: restrict east-west and north-south
- Diagnostic logs -> Log Analytics

### 3.5 DDoS Protection Plan (SC-5)

- Standard plan attached to Hub VNet
- Linked to all spoke VNets

---

## Phase 4 -- Centralized Logging and Monitoring (Management Subscription)

Deploy: `infra/04-logging/main.bicep`

| Resource | Purpose | NIST Control |
|----------|---------|-------------|
| Log Analytics Workspace | Central log sink, 365-day retention | AU-3, AU-4, AU-6, AU-7, AU-11 |
| Azure Monitor Diagnostic Settings | Route all resource logs to LAW | AU-2, AU-3, AU-12 |
| Microsoft Sentinel | SIEM/SOAR, threat detection | IR-4, IR-5, SI-4 |
| Azure Automation Account | Patch management, DSC | SI-2, CM-3 |
| Activity Log export | Subscription-level audit to LAW | AU-3, AU-6 |
| Microsoft Defender for Cloud | CSPM + CWP, all plans enabled | RA-5, SI-2, SI-4, SC-7 |

### 4.1 Diagnostic Settings Policy

Apply `DeployIfNotExists` policy at `Corp` management group:
- All resources must send diagnostics to the central Log Analytics workspace.

### 4.2 Alerts

| Alert | Threshold | NIST Control |
|-------|-----------|-------------|
| Sign-in failures | > 10 in 5 min | AC-7 |
| Privilege escalation | Any role assignment change | AC-6 |
| Resource deletion | Any delete operation | CM-3 |
| NSG modification | Any change | SC-7 |
| Policy non-compliance | Any new violation | CA-7 |

---

## Phase 5 -- Identity and Access Management

Deploy: `infra/05-identity/main.bicep`

| Control | Implementation | NIST Control |
|---------|---------------|-------------|
| RBAC | Custom roles, least privilege, no standing Owner access | AC-2, AC-3, AC-6 |
| PIM | JIT activation for Owner/Contributor, max 8 hr | AC-2(4), AC-6(1) |
| Conditional Access | Block legacy auth, require MFA, compliant device, named locations | AC-7, AC-17, IA-2, IA-5 |
| Service Principals | Federated credentials (no secrets), scoped to subscription | IA-4, IA-5 |
| Entra ID Access Reviews | Quarterly, auto-remove stale access | AC-2(3) |

### 5.1 RBAC Role Assignments (Deployment Stack)

| Scope | Role | Principal |
|-------|------|-----------|
| Corp MG | Reader | Security-Auditors-SG |
| Platform MG | Contributor | Platform-Team-SG |
| LandingZones MG | Contributor | Workload-Team-SG |
| Management Sub | Log Analytics Contributor | Platform-Team-SG |
| Connectivity Sub | Network Contributor | Network-Team-SG |

---

## Phase 6 -- Azure Policy (NIST 800-53 Rev 5) Assignments

Deploy: `infra/06-policy/main.bicep`

### 6.1 Built-in Initiative

Assign the built-in initiative **"NIST SP 800-53 Rev. 5"** at the `Corp` management group.

Policy Definition ID:
```
/providers/Microsoft.Authorization/policySetDefinitions/179d1daa-458f-4e47-8086-2a68d0d6c38f
```

This initiative contains 800+ policy definitions covering all 20 NIST 800-53
control families:

| Family | ID | Key Policies |
|--------|----|-------------|
| Access Control | AC | Require MFA, RBAC enforcement, JIT VM access |
| Audit and Accountability | AU | Diagnostic settings, log retention, activity log export |
| Security Assessment | CA | Defender for Cloud auto-provisioning, vulnerability assessment |
| Configuration Management | CM | Allowed resource types, tag enforcement, change tracking |
| Contingency Planning | CP | Geo-redundant backup, ASR replication |
| Identification and Authentication | IA | Managed identity, password policy, cert-based auth |
| Incident Response | IR | Sentinel enabled, alert rules, notification contacts |
| Maintenance | MA | Update management, patch compliance |
| Media Protection | MP | Disk encryption, storage encryption |
| Physical and Environmental | PE | (Azure datacenter responsibility -- inherited) |
| Planning | PL | (Organizational -- documented outside Azure) |
| Personnel Security | PS | (Organizational -- documented outside Azure) |
| Risk Assessment | RA | Defender vulnerability scanning, SQL VA |
| System and Services Acquisition | SA | (Organizational + template validation) |
| System and Communications Protection | SC | TLS 1.2+, encryption at rest, private endpoints, NSG |
| System and Information Integrity | SI | Antimalware, FIM, patching, alert on anomaly |
| Program Management | PM | (Organizational -- documented outside Azure) |

### 6.2 Custom Policies (supplement built-in)

| Policy | Effect | Purpose |
|--------|--------|---------|
| Deny public IP on NIC | Deny | SC-7: Boundary protection |
| Deny storage without private endpoint | Deny | SC-7, SC-8 |
| Deny SQL without TDE | Deny | SC-28: Encryption at rest |
| Require resource lock on RGs | DeployIfNotExists | CM-3: Change control |
| Require tags (Environment, Owner, CostCenter) | Deny | CM-8: Asset inventory |
| Deny unmanaged disks | Deny | SC-28 |

### 6.3 Exemptions

Track exemptions in `infra/06-policy/exemptions/` directory. Each exemption
must reference the control ID and include justification and expiry date.

---

## Phase 7 -- Encryption and Data Protection

Deploy: `infra/07-encryption/main.bicep`

| Control | Implementation | NIST Control |
|---------|---------------|-------------|
| Encryption at rest | Azure-managed keys (default), CMK for sensitive | SC-28 |
| Encryption in transit | TLS 1.2 minimum, enforce HTTPS | SC-8, SC-13 |
| Key Vault | One per subscription, RBAC model, soft-delete+purge-protect | SC-12 |
| Disk encryption | Azure Disk Encryption or EncryptionAtHost | SC-28 |
| Storage encryption | SSE with Microsoft-managed or CMK, require secure transfer | SC-28 |
| SQL TDE | Enabled by default, CMK option | SC-28 |

---

## Phase 8 -- Landing Zone Subscription Vending

Deploy: `infra/08-landing-zone/main.bicep`

For each new workload subscription, the deployment stack creates:

1. Subscription alias (under correct MG)
2. Resource groups: `rg-<workload>-app`, `rg-<workload>-data`, `rg-<workload>-infra`
3. Spoke VNet peered to Hub
4. UDR with default route to Azure Firewall
5. NSG with deny-all baseline
6. Diagnostic settings to central Log Analytics
7. Budget alert
8. Resource lock (CanNotDelete) on resource groups

---

## Phase 9 -- Backup and Disaster Recovery (CP family)

Deploy: `infra/09-bcdr/main.bicep`

| Resource | Configuration | NIST Control |
|----------|--------------|-------------|
| Recovery Services Vault | GRS, per landing zone | CP-9, CP-10 |
| Backup Policy (VM) | Daily, 30-day retention | CP-9 |
| Backup Policy (SQL) | Full weekly, diff daily, log 15-min | CP-9 |
| ASR | DR to paired region, RPO < 15 min | CP-2, CP-7 |

---

## Deployment Method -- Deployment Stacks

All Bicep templates are published as **Template Specs** and deployed via
**Deployment Stacks** at the appropriate scope:

```bash
# Publish a template spec
az ts create \
  --name "management-groups" \
  --version "1.0.0" \
  --resource-group rg-mgmt-automation \
  --template-file infra/01-management-groups/main.bicep

# Deploy as a Deployment Stack at tenant scope
az stack tenant create \
  --name "nist-mgmt-groups" \
  --location eastus \
  --template-spec "/subscriptions/{subId}/resourceGroups/rg-mgmt-automation/providers/Microsoft.Resources/templateSpecs/management-groups/versions/1.0.0" \
  --deny-settings-mode denyDelete \
  --action-on-unmanage detachAll
```

### Deployment Stack per Phase

| Stack Name | Scope | Deny Setting |
|-----------|-------|-------------|
| nist-mgmt-groups | Tenant | denyDelete |
| nist-platform-subs | Tenant | denyDelete |
| nist-hub-networking | Subscription (Connectivity) | denyWriteAndDelete |
| nist-logging | Subscription (Management) | denyWriteAndDelete |
| nist-identity | Subscription (Identity) | denyDelete |
| nist-policy-corp | Management Group (Corp) | denyDelete |
| nist-landing-zone-{name} | Subscription | denyDelete |
| nist-bcdr | Subscription | denyDelete |

---

## CI/CD Pipeline

```
Repo: azure-commercial-iac
  |
  +-- infra/
  |     +-- 01-management-groups/
  |     +-- 02-subscriptions/
  |     +-- 03-networking/
  |     +-- 04-logging/
  |     +-- 05-identity/
  |     +-- 06-policy/
  |     +-- 07-encryption/
  |     +-- 08-landing-zone/
  |     +-- 09-bcdr/
  |     +-- modules/          (shared Bicep modules)
  |
  +-- scripts/
  |     +-- deploy-all.sh
  |     +-- deploy-phase.sh
  |
  +-- .github/workflows/     (or azure-pipelines/)
        +-- deploy-infra.yml
```

Pipeline stages:
1. `lint` -- `az bicep lint` on all files
2. `validate` -- `az deployment {scope} validate`
3. `what-if` -- `az deployment {scope} what-if` (manual approval gate)
4. `deploy` -- `az stack {scope} create` (sequential by phase)

---

## NIST 800-53 Control-to-Azure Mapping Summary

| Control | Azure Implementation |
|---------|---------------------|
| AC-2 Account Management | Entra ID, PIM, Access Reviews, RBAC |
| AC-3 Access Enforcement | Azure RBAC, Conditional Access |
| AC-4 Information Flow | Azure Firewall, NSG, Private Endpoints |
| AC-6 Least Privilege | PIM, custom roles, deny assignments |
| AC-7 Unsuccessful Logon | Entra ID Smart Lockout, alerts |
| AC-17 Remote Access | Azure Bastion, Conditional Access, VPN |
| AU-2 Audit Events | Diagnostic Settings policy |
| AU-3 Content of Audit Records | Activity Log, resource logs |
| AU-6 Audit Review | Sentinel workbooks, KQL queries |
| AU-11 Audit Retention | Log Analytics 365-day retention |
| AU-12 Audit Generation | DeployIfNotExists diagnostic settings |
| CA-7 Continuous Monitoring | Defender for Cloud, Sentinel |
| CM-2 Baseline Configuration | Azure Policy, DSC |
| CM-8 Information System Inventory | Azure Resource Graph, tags |
| CP-9 System Backup | Recovery Services Vault, backup policies |
| IA-2 Identification | Entra ID MFA |
| IA-5 Authenticator Management | Entra ID password policies, FIDO2 |
| IR-4 Incident Handling | Sentinel playbooks, Logic Apps |
| RA-5 Vulnerability Scanning | Defender for Cloud, Qualys agent |
| SC-5 Denial of Service | DDoS Protection Standard |
| SC-7 Boundary Protection | Azure Firewall, NSG, ASG |
| SC-8 Transmission Confidentiality | TLS 1.2+, HTTPS-only |
| SC-12 Key Management | Key Vault, CMK |
| SC-28 Protection at Rest | Disk encryption, SSE, TDE |
| SI-2 Flaw Remediation | Update Management, Defender recommendations |
| SI-4 System Monitoring | Sentinel, Defender, Log Analytics alerts |

---

## Execution Timeline

| Week | Phase | Deliverable |
|------|-------|------------|
| 1 | Phase 0 | Prerequisites complete, repo created |
| 1-2 | Phase 1 | Management group hierarchy deployed |
| 2 | Phase 2 | Platform subscriptions + RGs created |
| 2-3 | Phase 3 | Hub-spoke networking operational |
| 3-4 | Phase 4 | Central logging, Sentinel, Defender enabled |
| 4 | Phase 5 | IAM: PIM, CA, RBAC configured |
| 4-5 | Phase 6 | NIST 800-53 policy initiative assigned, custom policies deployed |
| 5 | Phase 7 | Encryption controls in place |
| 5-6 | Phase 8 | First landing zone subscription vended |
| 6 | Phase 9 | Backup and DR configured |
| 7 | Validation | Compliance dashboard review, remediate non-compliant resources |

---

## Validation

1. **Regulatory Compliance dashboard** in Defender for Cloud -- select NIST SP 800-53 Rev. 5 standard
2. **Azure Policy compliance** -- check `Corp` MG scope for non-compliant resources
3. **Azure Resource Graph** queries to verify tag coverage, encryption status, NSG rules
4. **Sentinel hunting queries** to confirm log ingestion from all subscriptions
5. Export compliance report for auditors

---

## References

- [Azure Blueprints (deprecated) NIST 800-53 R4 sample](https://github.com/Azure/azure-blueprints/tree/master/samples/001-builtins/nist-sp-800-53-r4)
- [Template Specs](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/template-specs)
- [Deployment Stacks](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deployment-stacks)
- [Azure Landing Zone reference architecture](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/)
- [NIST SP 800-53 Rev. 5 built-in initiative](https://learn.microsoft.com/en-us/azure/governance/policy/samples/nist-sp-800-53-r5)
- [Azure Well-Architected Framework -- Security pillar](https://learn.microsoft.com/en-us/azure/well-architected/security/)
