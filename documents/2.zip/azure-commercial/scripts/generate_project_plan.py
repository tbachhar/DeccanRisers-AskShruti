#!/usr/bin/env python3
"""
Azure Commercial Cloud – NIST 800-53 Foundation
Hyperrealistic PMP-Grade Project Plan Generator

Generates a fully formatted Excel workbook with:
  - WBS-numbered tasks, chronologically sequenced
  - Status & Owner columns (blank for PM tracking)
  - Infrastructure phases + application-specific deployments
  - Conditional formatting, filters, freeze panes
"""

import os
from datetime import date, timedelta
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, NamedStyle, numbers
)
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

# ── Configuration ──────────────────────────────────────────────────────────
PROJECT_START = date(2026, 3, 2)  # Monday start
OUTPUT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "Azure-Commercial-NIST800-53-Project-Plan.xlsx")

APPLICATIONS = [
    ("Dataloom", "Data orchestration & pipeline management platform"),
    ("TorQE-T-MSIS", "T-MSIS quality & eligibility reporting engine"),
    ("Tessarix Medicaid Data Lakehouse", "Medicaid analytics data lakehouse"),
    ("Amida Connect Health Data Converter", "Health data interoperability & FHIR conversion"),
    ("Lighthouse - Data Quality Validation", "Data quality rules engine & validation service"),
    ("MDM Workbench", "Master Data Management workbench"),
    ("Saraswati - HEDIS Measure Mgmt & Scoring", "HEDIS clinical quality measure management"),
]

# ── Styles ─────────────────────────────────────────────────────────────────
DARK_BLUE   = "1F3864"
MED_BLUE    = "2E75B6"
LIGHT_BLUE  = "D6E4F0"
PHASE_GOLD  = "FFF2CC"
MILESTONE_GREEN = "E2EFDA"
APP_LAVENDER = "E8DAEF"
WHITE       = "FFFFFF"
LIGHT_GRAY  = "F2F2F2"

THIN_BORDER = Border(
    left=Side(style="thin", color="B4B4B4"),
    right=Side(style="thin", color="B4B4B4"),
    top=Side(style="thin", color="B4B4B4"),
    bottom=Side(style="thin", color="B4B4B4"),
)

HEADER_FONT   = Font(name="Calibri", bold=True, size=11, color=WHITE)
PHASE_FONT    = Font(name="Calibri", bold=True, size=11, color=DARK_BLUE)
TASK_FONT     = Font(name="Calibri", size=10)
SUBTASK_FONT  = Font(name="Calibri", size=10, italic=False)
TITLE_FONT    = Font(name="Calibri", bold=True, size=16, color=DARK_BLUE)
SUBTITLE_FONT = Font(name="Calibri", bold=False, size=11, color="595959")

HEADER_FILL   = PatternFill(start_color=DARK_BLUE, end_color=DARK_BLUE, fill_type="solid")
PHASE_FILL    = PatternFill(start_color=PHASE_GOLD, end_color=PHASE_GOLD, fill_type="solid")
MILESTONE_FILL = PatternFill(start_color=MILESTONE_GREEN, end_color=MILESTONE_GREEN, fill_type="solid")
APP_FILL      = PatternFill(start_color=APP_LAVENDER, end_color=APP_LAVENDER, fill_type="solid")
ALT_ROW_FILL  = PatternFill(start_color=LIGHT_GRAY, end_color=LIGHT_GRAY, fill_type="solid")
LIGHT_BLUE_FILL = PatternFill(start_color=LIGHT_BLUE, end_color=LIGHT_BLUE, fill_type="solid")

WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="top", wrap_text=True)
LEFT = Alignment(horizontal="left", vertical="top", wrap_text=True)

COLUMNS = [
    ("WBS #",            8),
    ("Phase",           18),
    ("Task Name",       48),
    ("Description",     55),
    ("Deliverable / Artifact",  38),
    ("Dependencies",    14),
    ("NIST 800-53 Controls", 22),
    ("Priority",        10),
    ("Start Date",      13),
    ("End Date",        13),
    ("Duration (Days)", 13),
    ("% Complete",      11),
    ("Status",          14),
    ("Owner",           22),
    ("RACI - Responsible",  20),
    ("RACI - Accountable",  20),
    ("RACI - Consulted",    20),
    ("RACI - Informed",     20),
    ("Risk / Blocker Notes", 35),
    ("Comments",        30),
]


# ── Helper ─────────────────────────────────────────────────────────────────
def d(offset_days):
    """Return PROJECT_START + offset business days."""
    current = PROJECT_START
    added = 0
    while added < offset_days:
        current += timedelta(days=1)
        if current.weekday() < 5:  # Mon-Fri
            added += 1
    return current


def week_range(start_bdays, duration_bdays):
    """Return (start_date, end_date, duration_bdays)."""
    s = d(start_bdays) if start_bdays > 0 else PROJECT_START
    e = d(start_bdays + duration_bdays)
    return s, e, duration_bdays


# ── Task Data ──────────────────────────────────────────────────────────────
# Each entry: (wbs, phase, task_name, description, deliverable, deps, nist, priority, start_bdays, duration_bdays, row_type)
# row_type: "phase", "milestone", "task", "subtask", "app_phase", "app_task"

def build_task_list():
    tasks = []

    # ═══════════════════════  PHASE 0  ═══════════════════════════════════
    tasks.append(("0", "Phase 0: Project Initiation & Prerequisites", "", "", "", "", "", "Critical", 0, 10, "phase"))
    tasks.append(("0.1", "Phase 0", "Project Charter & Kickoff", "Draft project charter, define scope, success criteria, and governance model", "Project Charter (signed)", "", "PM-1, PM-9", "Critical", 0, 3, "task"))
    tasks.append(("0.2", "Phase 0", "Stakeholder Register & Communication Plan", "Identify all stakeholders; define communication cadence, escalation paths", "Stakeholder Register, Comms Plan", "0.1", "PM-2", "Critical", 0, 3, "task"))
    tasks.append(("0.3", "Phase 0", "RACI Matrix Development", "Define RACI for all phases across platform, security, IAM, network, app teams", "RACI Matrix", "0.1", "", "High", 1, 2, "task"))
    tasks.append(("0.4", "Phase 0", "Risk Register Initialization", "Identify initial risks, assign owners, define mitigation strategies", "Risk Register", "0.1", "RA-3, PM-9", "High", 1, 2, "task"))
    tasks.append(("0.5", "Phase 0", "Enable Entra ID P2 Licensing", "Procure and activate Entra ID P2 for all admin users", "Entra ID P2 active", "0.1", "IA-2, AC-2", "Critical", 2, 2, "task"))
    tasks.append(("0.6", "Phase 0", "Create Break-Glass Accounts (x2)", "Create 2 emergency access accounts, exclude from Conditional Access, store credentials securely", "Break-glass accounts operational", "0.5", "AC-2, CP-13", "Critical", 3, 1, "task"))
    tasks.append(("0.7", "Phase 0", "Enable MFA for All Users", "Configure Conditional Access policy requiring MFA for all users (phased rollout)", "MFA enforcement policy active", "0.5", "AC-7, IA-2, IA-5", "Critical", 3, 3, "task"))
    tasks.append(("0.8", "Phase 0", "Register Required Resource Providers", "Register Microsoft.Blueprint, Microsoft.PolicyInsights, Microsoft.Security providers on all subs", "Resource providers registered", "0.5", "", "High", 4, 1, "task"))
    tasks.append(("0.9", "Phase 0", "Install & Configure Tooling", "Install Az CLI, Bicep CLI, Az PowerShell; validate versions; configure extensions", "Dev tooling validated", "", "", "High", 2, 2, "task"))
    tasks.append(("0.10", "Phase 0", "Create IaC Repository (azure-commercial-iac)", "Initialize Git repo, branch policies (main protected), PR templates, CODEOWNERS", "IaC repo with branch policies", "0.9", "CM-2, CM-9, SA-3", "Critical", 3, 2, "task"))
    tasks.append(("0.11", "Phase 0", "Create Deployment SPN & Federated Credentials", "Create SPN, assign Owner on Tenant Root Group, configure OIDC federation for CI/CD", "SPN with federated credential", "0.5, 0.10", "IA-4, IA-5", "Critical", 5, 2, "task"))
    tasks.append(("0.12", "Phase 0", "CI/CD Pipeline Scaffolding", "Create pipeline YAML (lint → validate → what-if → deploy), approval gates, environments", "CI/CD pipeline (dry run passing)", "0.10, 0.11", "CM-3, SA-3", "High", 6, 3, "task"))
    tasks.append(("0.13", "Phase 0", "Security Categorization (FIPS 199)", "Categorize system per FIPS 199; determine impact levels; document in SSP", "Security Categorization Document", "0.1", "RA-2, PL-2", "Critical", 1, 3, "task"))
    tasks.append(("M0", "Phase 0", "MILESTONE: Phase 0 Complete – Foundation Ready", "All prerequisites validated, tooling operational, repo and pipeline functional", "Phase 0 Gate Review", "0.1–0.13", "", "Critical", 9, 0, "milestone"))

    # ═══════════════════════  PHASE 1  ═══════════════════════════════════
    tasks.append(("1", "Phase 1: Management Group Hierarchy", "", "", "", "", "", "Critical", 10, 5, "phase"))
    tasks.append(("1.1", "Phase 1", "Design Management Group Taxonomy", "Finalize MG hierarchy: Corp → Platform/LandingZones/Sandbox/Decommissioned", "MG design document (approved)", "M0", "AC-1, PM-9", "Critical", 10, 2, "task"))
    tasks.append(("1.2", "Phase 1", "Develop Bicep Template (01-management-groups/main.bicep)", "Author Bicep for full MG tree with parameterized naming", "Bicep template (PR approved)", "1.1", "CM-2, CM-9", "Critical", 12, 2, "task"))
    tasks.append(("1.3", "Phase 1", "Deploy Management Groups via Deployment Stack", "Deploy at tenant scope; validate hierarchy in portal", "MG hierarchy deployed", "1.2", "AC-1, AU-1, PM-9", "Critical", 14, 1, "task"))
    tasks.append(("1.4", "Phase 1", "Validate & Document MG Structure", "Screenshot portal, confirm inheritance paths, update architecture docs", "Updated architecture diagram", "1.3", "", "High", 14, 1, "task"))
    tasks.append(("M1", "Phase 1", "MILESTONE: Management Group Hierarchy Deployed", "MG hierarchy operational and documented", "Phase 1 Gate Review", "1.3, 1.4", "", "Critical", 15, 0, "milestone"))

    # ═══════════════════════  PHASE 2  ═══════════════════════════════════
    tasks.append(("2", "Phase 2: Platform Subscriptions & Resource Groups", "", "", "", "", "", "Critical", 15, 8, "phase"))
    tasks.append(("2.1", "Phase 2", "Provision Identity Subscription", "Create subscription, place under Platform MG, configure initial settings", "Identity subscription active", "M1", "AC-2, IA-1", "Critical", 15, 2, "task"))
    tasks.append(("2.2", "Phase 2", "Provision Management Subscription", "Create subscription, place under Platform MG", "Management subscription active", "M1", "AU-1, SI-4", "Critical", 15, 2, "task"))
    tasks.append(("2.3", "Phase 2", "Provision Connectivity Subscription", "Create subscription, place under Platform MG", "Connectivity subscription active", "M1", "SC-7, AC-4", "Critical", 15, 2, "task"))
    tasks.append(("2.4", "Phase 2", "Create Identity Resource Groups", "rg-identity-adds, rg-identity-pki", "RGs created with tags", "2.1", "CM-8", "High", 17, 1, "task"))
    tasks.append(("2.5", "Phase 2", "Create Management Resource Groups", "rg-mgmt-logging, rg-mgmt-automation, rg-mgmt-sentinel", "RGs created with tags", "2.2", "CM-8", "High", 17, 1, "task"))
    tasks.append(("2.6", "Phase 2", "Create Connectivity Resource Groups", "rg-conn-hub, rg-conn-firewall, rg-conn-dns, rg-conn-gateway", "RGs created with tags", "2.3", "CM-8", "High", 17, 1, "task"))
    tasks.append(("2.7", "Phase 2", "Apply Resource Locks on All Platform RGs", "CanNotDelete locks on every platform RG", "Resource locks confirmed", "2.4, 2.5, 2.6", "CM-3", "High", 18, 1, "task"))
    tasks.append(("2.8", "Phase 2", "Apply Tagging Standards (Environment, Owner, CostCenter)", "Enforce required tags via policy or manual application", "Tags validated via Resource Graph", "2.4, 2.5, 2.6", "CM-8", "High", 18, 1, "task"))
    tasks.append(("2.9", "Phase 2", "Deploy Bicep via Deployment Stack (02-subscriptions)", "Publish Template Spec, deploy stack at tenant scope", "Deployment stack operational", "2.7", "CM-2", "Critical", 19, 2, "task"))
    tasks.append(("M2", "Phase 2", "MILESTONE: Platform Subscriptions & RGs Ready", "All platform subs and RGs provisioned, locked, tagged", "Phase 2 Gate Review", "2.9", "", "Critical", 22, 0, "milestone"))

    # ═══════════════════════  PHASE 3  ═══════════════════════════════════
    tasks.append(("3", "Phase 3: Hub-Spoke Networking", "", "", "", "", "", "Critical", 22, 15, "phase"))
    tasks.append(("3.1", "Phase 3", "Hub VNet Design & IP Address Plan", "Design Hub VNet (10.0.0.0/16), subnets, spoke CIDR allocations, document IPAM", "Network design document", "M2", "SC-7, AC-4", "Critical", 22, 3, "task"))
    tasks.append(("3.2", "Phase 3", "Deploy Hub VNet & Subnets", "AzureFirewallSubnet, GatewaySubnet, AzureBastionSubnet, DNS subnets", "Hub VNet deployed", "3.1", "SC-7", "Critical", 25, 2, "task"))
    tasks.append(("3.3", "Phase 3", "Deploy Azure Firewall (Premium)", "Firewall with threat intel (Alert+Deny), TLS inspection, application/network rules", "Azure Firewall operational", "3.2", "SC-7, AC-4, AU-12", "Critical", 27, 3, "task"))
    tasks.append(("3.4", "Phase 3", "Configure Azure Firewall Rules & Policies", "Outbound allow-list, east-west restrictions, DNAT rules, diagnostic logs to LAW", "Firewall policy applied", "3.3", "SC-7, AC-4", "Critical", 30, 2, "task"))
    tasks.append(("3.5", "Phase 3", "Deploy Azure Bastion (Standard SKU)", "Deploy to AzureBastionSubnet with native client support", "Bastion operational", "3.2", "AC-17, SC-7", "High", 27, 2, "task"))
    tasks.append(("3.6", "Phase 3", "Deploy VPN Gateway / ExpressRoute Gateway", "Deploy VPN GW (or ER GW) in GatewaySubnet, configure connections", "Gateway deployed", "3.2", "AC-17, SC-8, SC-13", "High", 29, 3, "task"))
    tasks.append(("3.7", "Phase 3", "Deploy DNS Private Resolver", "Inbound & outbound endpoints, conditional forwarding rules", "DNS resolver operational", "3.2", "SC-20, SC-21", "High", 27, 2, "task"))
    tasks.append(("3.8", "Phase 3", "Deploy DDoS Protection Standard Plan", "Attach to Hub VNet, link to all future spoke VNets", "DDoS plan active", "3.2", "SC-5", "High", 25, 1, "task"))
    tasks.append(("3.9", "Phase 3", "Deploy Production Spoke VNet (10.1.0.0/16)", "Subnets, peering to Hub, UDR (0.0.0.0/0 → Firewall)", "Prod spoke operational", "3.3", "SC-7, AC-4", "Critical", 32, 2, "task"))
    tasks.append(("3.10", "Phase 3", "Deploy Dev Spoke VNet (10.2.0.0/16)", "Subnets, peering to Hub, UDR (0.0.0.0/0 → Firewall)", "Dev spoke operational", "3.3", "SC-7, AC-4", "High", 32, 2, "task"))
    tasks.append(("3.11", "Phase 3", "NSG Baseline Deployment (All Subnets)", "Deny-all inbound default, allow required ports, NSG flow logs to LAW", "NSG baselines applied", "3.9, 3.10", "SC-7, AU-3, AU-12", "Critical", 34, 2, "task"))
    tasks.append(("3.12", "Phase 3", "Network Connectivity Validation", "Test peering, firewall rules, DNS resolution, Bastion access, VPN tunnel", "Connectivity test report", "3.11", "", "Critical", 36, 1, "task"))
    tasks.append(("M3", "Phase 3", "MILESTONE: Hub-Spoke Networking Operational", "Full network topology validated end-to-end", "Phase 3 Gate Review", "3.12", "SC-7, AC-4", "Critical", 37, 0, "milestone"))

    # ═══════════════════════  PHASE 4  ═══════════════════════════════════
    tasks.append(("4", "Phase 4: Centralized Logging & Monitoring", "", "", "", "", "", "Critical", 32, 15, "phase"))
    tasks.append(("4.1", "Phase 4", "Deploy Log Analytics Workspace (365-day retention)", "Central LAW in Management sub, capacity reservation, archive tier config", "LAW deployed", "M2", "AU-3, AU-4, AU-6, AU-11", "Critical", 32, 2, "task"))
    tasks.append(("4.2", "Phase 4", "Configure Activity Log Export (All Subscriptions)", "Export subscription-level Activity Logs to central LAW", "Activity logs flowing", "4.1", "AU-2, AU-3, AU-6", "Critical", 34, 2, "task"))
    tasks.append(("4.3", "Phase 4", "Deploy Azure Monitor Diagnostic Settings Policy", "DeployIfNotExists policy at Corp MG for all resource types", "Diagnostic policy assigned", "4.1", "AU-2, AU-12", "Critical", 34, 3, "task"))
    tasks.append(("4.4", "Phase 4", "Deploy Microsoft Sentinel", "Enable Sentinel on LAW, configure data connectors (Entra ID, Activity, Defender)", "Sentinel operational", "4.1", "IR-4, IR-5, SI-4", "Critical", 36, 3, "task"))
    tasks.append(("4.5", "Phase 4", "Configure Sentinel Analytics Rules", "Enable built-in rules, configure custom rules for AC-7, AC-6, CM-3, SC-7", "Analytics rules active", "4.4", "IR-4, SI-4, AU-6", "High", 39, 3, "task"))
    tasks.append(("4.6", "Phase 4", "Configure Sentinel Playbooks (SOAR)", "Create Logic Apps for auto-response: isolate VM, disable account, notify SOC", "Playbooks operational", "4.4", "IR-4, IR-6", "High", 39, 3, "task"))
    tasks.append(("4.7", "Phase 4", "Deploy Azure Automation Account", "Automation account for patch management, DSC, runbooks", "Automation account deployed", "M2", "SI-2, CM-3", "High", 34, 2, "task"))
    tasks.append(("4.8", "Phase 4", "Enable Microsoft Defender for Cloud (All Plans)", "CSPM + CWP: Servers, SQL, Storage, App Service, Key Vault, DNS, ARM, Containers", "Defender for Cloud enabled", "4.1", "RA-5, SI-2, SI-4, SC-7", "Critical", 36, 2, "task"))
    tasks.append(("4.9", "Phase 4", "Configure Alert Rules", "Sign-in failures (>10/5min), privilege escalation, resource deletion, NSG changes, policy violations", "Alert rules active", "4.4, 4.8", "AC-7, AC-6, CM-3, SC-7, CA-7", "High", 40, 2, "task"))
    tasks.append(("4.10", "Phase 4", "Create Monitoring Dashboards & Workbooks", "Sentinel workbooks, Azure Monitor dashboards for compliance KPIs", "Dashboards published", "4.4, 4.8", "AU-6, CA-7", "Medium", 42, 2, "task"))
    tasks.append(("4.11", "Phase 4", "Validate Log Ingestion & Retention", "Confirm all subs/resources sending logs, verify retention settings, test queries", "Log validation report", "4.3, 4.4", "AU-6, AU-11", "Critical", 44, 2, "task"))
    tasks.append(("M4", "Phase 4", "MILESTONE: Centralized Logging & SIEM Operational", "All logs flowing, Sentinel detecting, alerts firing", "Phase 4 Gate Review", "4.11", "", "Critical", 46, 0, "milestone"))

    # ═══════════════════════  PHASE 5  ═══════════════════════════════════
    tasks.append(("5", "Phase 5: Identity & Access Management", "", "", "", "", "", "Critical", 37, 13, "phase"))
    tasks.append(("5.1", "Phase 5", "Design RBAC Model (Custom Roles)", "Define custom roles per team: Platform, Network, Security, Workload; no standing Owner", "RBAC design doc", "M1", "AC-2, AC-3, AC-6", "Critical", 37, 3, "task"))
    tasks.append(("5.2", "Phase 5", "Deploy Custom RBAC Roles", "Create and assign custom roles at appropriate scopes via Bicep", "Custom roles deployed", "5.1", "AC-3, AC-6", "Critical", 40, 2, "task"))
    tasks.append(("5.3", "Phase 5", "Configure Privileged Identity Management (PIM)", "JIT activation for Owner/Contributor (max 8hr duration), approval workflows", "PIM configured", "5.2", "AC-2(4), AC-6(1), AC-6(5)", "Critical", 42, 3, "task"))
    tasks.append(("5.4", "Phase 5", "Configure Conditional Access Policies", "Block legacy auth, require MFA, require compliant device, named locations, session controls", "CA policies active", "0.7", "AC-7, AC-17, IA-2, IA-5, AC-11", "Critical", 37, 4, "task"))
    tasks.append(("5.5", "Phase 5", "Configure Entra ID Access Reviews", "Quarterly reviews for privileged roles, auto-remove stale access", "Access Reviews scheduled", "5.3", "AC-2(3), AC-6(7)", "High", 45, 2, "task"))
    tasks.append(("5.6", "Phase 5", "Configure Service Principal Governance", "Federated credentials (no secrets), scoped to subscription, inventory in Key Vault", "SP governance operational", "5.2", "IA-4, IA-5, IA-5(7)", "High", 42, 2, "task"))
    tasks.append(("5.7", "Phase 5", "RBAC Role Assignment Deployment (Deployment Stack)", "Deploy role assignments at MG/Sub scopes per design", "Role assignments deployed", "5.2, 5.3", "AC-2, AC-3", "Critical", 45, 2, "task"))
    tasks.append(("5.8", "Phase 5", "Configure Entra ID Identity Protection", "Risk-based sign-in and user risk policies, UEBA integration", "Identity Protection active", "5.4", "AC-2(12), AC-2(13), IA-10", "High", 44, 2, "task"))
    tasks.append(("5.9", "Phase 5", "IAM Validation & Penetration Test", "Test RBAC enforcement, PIM activation, CA block scenarios, break-glass access", "IAM test report", "5.7, 5.8", "CA-8", "Critical", 47, 3, "task"))
    tasks.append(("M5", "Phase 5", "MILESTONE: IAM Fully Configured & Tested", "RBAC, PIM, CA, Access Reviews all operational and validated", "Phase 5 Gate Review", "5.9", "", "Critical", 50, 0, "milestone"))

    # ═══════════════════════  PHASE 6  ═══════════════════════════════════
    tasks.append(("6", "Phase 6: Azure Policy – NIST 800-53 Rev 5", "", "", "", "", "", "Critical", 45, 15, "phase"))
    tasks.append(("6.1", "Phase 6", "Assign Built-in NIST 800-53 Rev 5 Initiative", "Assign at Corp MG; configure parameters (LAW ID, allowed locations, etc.)", "Initiative assigned", "M1", "All 20 families", "Critical", 45, 3, "task"))
    tasks.append(("6.2", "Phase 6", "Develop Custom Policy: Deny Public IP on NIC", "Author, test, deploy custom policy definition", "Custom policy active", "6.1", "SC-7", "High", 48, 2, "task"))
    tasks.append(("6.3", "Phase 6", "Develop Custom Policy: Deny Storage Without Private Endpoint", "Author, test, deploy custom policy definition", "Custom policy active", "6.1", "SC-7, SC-8", "High", 48, 2, "task"))
    tasks.append(("6.4", "Phase 6", "Develop Custom Policy: Deny SQL Without TDE", "Author, test, deploy custom policy definition", "Custom policy active", "6.1", "SC-28", "High", 48, 2, "task"))
    tasks.append(("6.5", "Phase 6", "Develop Custom Policy: Require Resource Locks on RGs", "DeployIfNotExists policy for CanNotDelete locks", "Custom policy active", "6.1", "CM-3", "High", 50, 2, "task"))
    tasks.append(("6.6", "Phase 6", "Develop Custom Policy: Require Tags", "Deny if missing Environment, Owner, CostCenter tags", "Custom policy active", "6.1", "CM-8", "High", 50, 2, "task"))
    tasks.append(("6.7", "Phase 6", "Develop Custom Policy: Deny Unmanaged Disks", "Author, test, deploy custom policy definition", "Custom policy active", "6.1", "SC-28", "High", 50, 2, "task"))
    tasks.append(("6.8", "Phase 6", "Policy Remediation Tasks", "Run remediation for DeployIfNotExists policies, resolve non-compliant resources", "Remediation complete", "6.1–6.7", "CA-5, CA-7", "High", 52, 3, "task"))
    tasks.append(("6.9", "Phase 6", "Create Exemption Framework & Templates", "Establish exemption process, template (control ID, justification, expiry), store in infra/06-policy/exemptions/", "Exemption framework", "6.1", "CA-5", "Medium", 52, 2, "task"))
    tasks.append(("6.10", "Phase 6", "Policy Compliance Validation", "Review Defender for Cloud NIST 800-53 compliance dashboard, document gaps", "Compliance report (initial)", "6.8", "CA-2, CA-7", "Critical", 55, 3, "task"))
    tasks.append(("M6", "Phase 6", "MILESTONE: NIST 800-53 Policy Suite Deployed", "Built-in + custom policies assigned, remediated, compliance > 85%", "Phase 6 Gate Review", "6.10", "", "Critical", 58, 0, "milestone"))

    # ═══════════════════════  PHASE 7  ═══════════════════════════════════
    tasks.append(("7", "Phase 7: Encryption & Data Protection", "", "", "", "", "", "High", 52, 10, "phase"))
    tasks.append(("7.1", "Phase 7", "Deploy Key Vault (Per Subscription)", "RBAC model, soft-delete + purge-protection, diagnostic logs to LAW", "Key Vaults deployed", "M2", "SC-12, AU-12", "Critical", 52, 2, "task"))
    tasks.append(("7.2", "Phase 7", "Configure CMK for Sensitive Workloads", "Customer-managed keys for Storage, SQL, Disk Encryption as required", "CMK policies active", "7.1", "SC-12, SC-28", "High", 54, 3, "task"))
    tasks.append(("7.3", "Phase 7", "Enforce TLS 1.2 Minimum (Policy)", "Policy to deny resources not using TLS 1.2+", "TLS policy enforced", "6.1", "SC-8, SC-13", "Critical", 52, 2, "task"))
    tasks.append(("7.4", "Phase 7", "Configure Disk Encryption (EncryptionAtHost)", "Enable for all VM SKUs, enforce via policy", "Disk encryption active", "7.1", "SC-28", "High", 54, 2, "task"))
    tasks.append(("7.5", "Phase 7", "Configure Storage SSE & Require Secure Transfer", "Enforce HTTPS-only, SSE with CMK where required", "Storage encryption validated", "7.1", "SC-28, SC-8", "High", 54, 2, "task"))
    tasks.append(("7.6", "Phase 7", "SQL TDE Validation & CMK Configuration", "Verify TDE enabled, configure CMK for regulated databases", "SQL encryption validated", "7.1", "SC-28", "High", 56, 2, "task"))
    tasks.append(("7.7", "Phase 7", "Encryption Compliance Validation", "Audit all resources for encryption at rest/transit compliance", "Encryption audit report", "7.2–7.6", "SC-12, SC-28", "Critical", 58, 2, "task"))
    tasks.append(("M7", "Phase 7", "MILESTONE: Encryption Controls Operational", "All encryption requirements met and validated", "Phase 7 Gate Review", "7.7", "", "Critical", 60, 0, "milestone"))

    # ═══════════════════════  PHASE 8  ═══════════════════════════════════
    tasks.append(("8", "Phase 8: Landing Zone Subscription Vending", "", "", "", "", "", "Critical", 55, 12, "phase"))
    tasks.append(("8.1", "Phase 8", "Design Landing Zone Template", "Parameterized Bicep: sub alias, MG placement, RGs, spoke VNet, UDR, NSG, diag, budget, locks", "LZ Bicep template", "M3, M4", "AC-4, SC-7, AU-12, CM-8", "Critical", 55, 4, "task"))
    tasks.append(("8.2", "Phase 8", "Deploy Production Landing Zone Subscription", "First production LZ subscription under Production MG", "Prod LZ operational", "8.1", "", "Critical", 59, 3, "task"))
    tasks.append(("8.3", "Phase 8", "Deploy Dev/Test Landing Zone Subscription", "Dev LZ subscription under Non-Production MG", "Dev LZ operational", "8.1", "", "High", 59, 3, "task"))
    tasks.append(("8.4", "Phase 8", "Validate Landing Zone Compliance", "Verify spoke peering, UDR, NSG, diagnostics, tags, locks, policy compliance", "LZ compliance report", "8.2, 8.3", "CA-7", "Critical", 62, 3, "task"))
    tasks.append(("8.5", "Phase 8", "Document Landing Zone Vending Runbook", "Operational runbook for provisioning new LZ subscriptions (repeatable process)", "LZ Vending Runbook", "8.4", "SA-3, CM-9", "High", 65, 2, "task"))
    tasks.append(("M8", "Phase 8", "MILESTONE: Landing Zones Ready for Workloads", "Production & Dev LZs validated, vending process documented", "Phase 8 Gate Review", "8.5", "", "Critical", 67, 0, "milestone"))

    # ═══════════════════════  PHASE 9  ═══════════════════════════════════
    tasks.append(("9", "Phase 9: Backup & Disaster Recovery", "", "", "", "", "", "High", 60, 12, "phase"))
    tasks.append(("9.1", "Phase 9", "Deploy Recovery Services Vault (GRS)", "RSV in each landing zone sub, GRS replication", "RSVs deployed", "M2", "CP-9, CP-10", "High", 60, 2, "task"))
    tasks.append(("9.2", "Phase 9", "Configure VM Backup Policy", "Daily backups, 30-day retention, instant restore 2-day", "VM backup policy active", "9.1", "CP-9", "High", 62, 2, "task"))
    tasks.append(("9.3", "Phase 9", "Configure SQL Backup Policy", "Full weekly, differential daily, log backup every 15 min", "SQL backup policy active", "9.1", "CP-9", "High", 62, 2, "task"))
    tasks.append(("9.4", "Phase 9", "Configure Azure Site Recovery (ASR)", "DR replication to paired region, RPO < 15 min, test failover plan", "ASR replication active", "9.1, M3", "CP-2, CP-7, CP-10", "High", 64, 3, "task"))
    tasks.append(("9.5", "Phase 9", "DR Failover Test", "Execute test failover to paired region, validate app functionality, document results", "DR test report", "9.4", "CP-4, CP-4(2)", "Critical", 67, 3, "task"))
    tasks.append(("9.6", "Phase 9", "Backup Restore Validation", "Test restore of VM and SQL backups, validate data integrity", "Restore test report", "9.2, 9.3", "CP-9(1)", "High", 67, 2, "task"))
    tasks.append(("M9", "Phase 9", "MILESTONE: BCDR Operational & Tested", "Backup and DR validated with successful failover and restore", "Phase 9 Gate Review", "9.5, 9.6", "", "Critical", 72, 0, "milestone"))

    # ═══════════════════════  PHASE 10: APPLICATION DEPLOYMENTS  ═══════════
    app_start = 67  # Start after LZ ready
    phase_num = 10
    sub_phase = 0

    for app_name, app_desc in APPLICATIONS:
        sub_phase += 1
        prefix = f"10.{sub_phase}"
        app_short = app_name.split(" - ")[0].split(" –")[0].strip()

        tasks.append((prefix, f"Phase 10.{sub_phase}: {app_short}", f"", f"", "", "", "", "High", app_start, 20, "app_phase"))

        tasks.append((f"{prefix}.1", f"Phase 10.{sub_phase}", f"Application Architecture & Security Review – {app_short}", f"Review application architecture, data flows, security requirements for {app_desc}", "App security design doc", "M8", "SA-3, SA-4, PL-8, RA-3", "Critical", app_start, 3, "app_task"))
        tasks.append((f"{prefix}.2", f"Phase 10.{sub_phase}", f"Provision Resource Group – rg-{app_short.lower().replace(' ', '-')}", f"Create dedicated RG in target subscription with required tags and locks", "RG provisioned", f"{prefix}.1", "CM-8, CM-3", "High", app_start + 3, 1, "app_task"))
        tasks.append((f"{prefix}.3", f"Phase 10.{sub_phase}", f"Network Configuration – {app_short}", f"Subnet allocation, NSG rules, private endpoints, service endpoints", "Network config applied", f"{prefix}.2, M3", "SC-7, AC-4, SC-8", "High", app_start + 4, 2, "app_task"))
        tasks.append((f"{prefix}.4", f"Phase 10.{sub_phase}", f"Database / Data Store Provisioning – {app_short}", f"Deploy SQL/Cosmos/ADLS/Synapse as required; configure TDE, CMK, private endpoints, backup", "Data stores deployed", f"{prefix}.3, M7", "SC-28, SC-12, CP-9", "High", app_start + 6, 3, "app_task"))
        tasks.append((f"{prefix}.5", f"Phase 10.{sub_phase}", f"Compute & App Service Provisioning – {app_short}", f"Deploy AKS/App Service/Function/VM as required; configure managed identity, scaling", "Compute resources deployed", f"{prefix}.3", "CM-7, IA-4, SC-28", "High", app_start + 6, 3, "app_task"))
        tasks.append((f"{prefix}.6", f"Phase 10.{sub_phase}", f"Key Vault & Secrets Management – {app_short}", f"App-specific Key Vault, store connection strings, configure managed identity access", "Key Vault operational", f"{prefix}.2, 7.1", "SC-12, IA-5(6), IA-5(7)", "High", app_start + 4, 2, "app_task"))
        tasks.append((f"{prefix}.7", f"Phase 10.{sub_phase}", f"CI/CD Pipeline Setup – {app_short}", f"Create build + release pipeline, environment approvals, IaC + app deployment stages", "CI/CD pipeline operational", f"{prefix}.2, 0.12", "CM-3, SA-3, CM-2", "Critical", app_start + 6, 3, "app_task"))
        tasks.append((f"{prefix}.8", f"Phase 10.{sub_phase}", f"Monitoring & Alerting – {app_short}", f"Application Insights, custom dashboards, health probes, alert rules → Sentinel", "Monitoring configured", f"{prefix}.5, 4.1", "SI-4, AU-12, AU-6, CA-7", "High", app_start + 9, 2, "app_task"))
        tasks.append((f"{prefix}.9", f"Phase 10.{sub_phase}", f"Diagnostic Settings & Log Integration – {app_short}", f"All resource logs → central LAW, application logs → App Insights", "Diagnostics validated", f"{prefix}.8", "AU-2, AU-3, AU-12", "High", app_start + 11, 1, "app_task"))
        tasks.append((f"{prefix}.10", f"Phase 10.{sub_phase}", f"Security Hardening & Vulnerability Scan – {app_short}", f"Defender recommendations, vulnerability scan, WAF rules (if web-facing), pen test", "Security scan report", f"{prefix}.5", "RA-5, SI-2, SC-7, CA-8", "Critical", app_start + 12, 3, "app_task"))
        tasks.append((f"{prefix}.11", f"Phase 10.{sub_phase}", f"Backup Configuration – {app_short}", f"Configure backup policies for app compute and data stores per CP-9 requirements", "Backup policies active", f"{prefix}.4, 9.1", "CP-9, CP-10", "High", app_start + 9, 2, "app_task"))
        tasks.append((f"{prefix}.12", f"Phase 10.{sub_phase}", f"Application Deployment (Initial) – {app_short}", f"Deploy application via CI/CD pipeline to staging slot; smoke test", "App deployed to staging", f"{prefix}.7, {prefix}.5", "CM-3, SA-3", "Critical", app_start + 12, 2, "app_task"))
        tasks.append((f"{prefix}.13", f"Phase 10.{sub_phase}", f"UAT & Integration Testing – {app_short}", f"User acceptance testing, integration test with dependent services", "UAT sign-off", f"{prefix}.12", "CA-2, SA-4", "Critical", app_start + 14, 3, "app_task"))
        tasks.append((f"{prefix}.14", f"Phase 10.{sub_phase}", f"Production Go-Live – {app_short}", f"Swap to production slot, DNS cutover, smoke test, war room / hypercare", "App live in production", f"{prefix}.13", "CM-3", "Critical", app_start + 17, 2, "app_task"))
        tasks.append((f"{prefix}.15", f"Phase 10.{sub_phase}", f"Post-Go-Live Stabilization – {app_short}", f"Hypercare period, monitor performance/errors, address P1/P2 defects", "Stabilization complete", f"{prefix}.14", "SI-4, IR-4", "High", app_start + 19, 3, "app_task"))
        milestone_wbs = f"M10.{sub_phase}"
        tasks.append((milestone_wbs, f"Phase 10.{sub_phase}", f"MILESTONE: {app_short} – Production Ready", f"{app_short} fully deployed, tested, and in production", f"{app_short} Go-Live sign-off", f"{prefix}.15", "", "Critical", app_start + 22, 0, "milestone"))

        app_start += 10  # Stagger each app by 10 business days (2 weeks)

    # ═══════════════════════  PHASE 11  ═══════════════════════════════════
    final_app_end = app_start + 12
    tasks.append(("11", "Phase 11: Compliance Validation & Audit Prep", "", "", "", "", "", "Critical", final_app_end, 12, "phase"))
    tasks.append(("11.1", "Phase 11", "Regulatory Compliance Dashboard Review", "Review Defender for Cloud NIST 800-53 Rev 5 compliance; document all findings", "Compliance assessment report", "M6", "CA-2, CA-7", "Critical", final_app_end, 3, "task"))
    tasks.append(("11.2", "Phase 11", "POA&M Development", "Create Plan of Action & Milestones for all non-compliant controls", "POA&M document", "11.1", "CA-5, PM-4", "Critical", final_app_end + 3, 3, "task"))
    tasks.append(("11.3", "Phase 11", "Remediate Non-Compliant Resources", "Execute remediation for all identified findings", "Remediation evidence", "11.2", "CA-5, RA-7", "Critical", final_app_end + 6, 5, "task"))
    tasks.append(("11.4", "Phase 11", "Azure Resource Graph Validation Queries", "Tag coverage, encryption status, NSG rules, diagnostic settings verification", "Resource Graph query results", "11.1", "CM-8, SC-28, SC-7, AU-12", "High", final_app_end + 3, 2, "task"))
    tasks.append(("11.5", "Phase 11", "Sentinel Log Ingestion Verification", "Confirm log ingestion from all subscriptions and resources via hunting queries", "Log ingestion report", "M4", "AU-6, SI-4", "High", final_app_end + 3, 2, "task"))
    tasks.append(("11.6", "Phase 11", "Penetration Test (Third-Party)", "Engage third-party pen test provider, test infrastructure and applications", "Pen test report", "M8", "CA-8, CA-8(1), RA-5", "Critical", final_app_end + 5, 5, "task"))
    tasks.append(("11.7", "Phase 11", "Compliance Report Generation for Auditors", "Export compliance data, compile evidence packages, prepare audit binder", "Audit-ready compliance package", "11.3, 11.6", "CA-2, CA-7", "Critical", final_app_end + 10, 3, "task"))
    tasks.append(("M11", "Phase 11", "MILESTONE: Audit-Ready Compliance Package Complete", "System Authority to Operate (ATO) package prepared", "ATO package submitted", "11.7", "CA-6", "Critical", final_app_end + 13, 0, "milestone"))

    # ═══════════════════════  PHASE 12  ═══════════════════════════════════
    closeout_start = final_app_end + 13
    tasks.append(("12", "Phase 12: Project Closeout", "", "", "", "", "", "High", closeout_start, 5, "phase"))
    tasks.append(("12.1", "Phase 12", "Lessons Learned Workshop", "Conduct retrospective with all teams, document lessons learned", "Lessons Learned Report", "M11", "PM-14", "High", closeout_start, 2, "task"))
    tasks.append(("12.2", "Phase 12", "Operational Handoff Documentation", "Compile runbooks, architecture diagrams, contact matrices, escalation paths", "Operations Handbook", "M11", "PL-2, SA-3", "Critical", closeout_start, 3, "task"))
    tasks.append(("12.3", "Phase 12", "Knowledge Transfer Sessions", "Conduct KT sessions for operations team on all Phase 0-11 deliverables", "KT session recordings", "12.2", "AT-3", "High", closeout_start + 3, 2, "task"))
    tasks.append(("12.4", "Phase 12", "Transition to Continuous Monitoring (Steady State)", "Hand off to operations, establish BAU monitoring cadence, close project", "Transition complete", "12.3", "CA-7, PM-31", "Critical", closeout_start + 3, 2, "task"))
    tasks.append(("M12", "Phase 12", "MILESTONE: Project Complete", "All deliverables accepted, project formally closed", "Project Closure Report", "12.4", "", "Critical", closeout_start + 5, 0, "milestone"))

    return tasks


# ── Excel Generator ────────────────────────────────────────────────────────
def generate_workbook():
    wb = Workbook()
    ws = wb.active
    ws.title = "Project Plan"

    # ── Title Block ────────────────────────────────────────────────
    ws.merge_cells("A1:T1")
    ws["A1"] = "Azure Commercial Tenant – NIST 800-53 Rev 5 Foundation Project Plan"
    ws["A1"].font = TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 32

    ws.merge_cells("A2:T2")
    ws["A2"] = f"Project Start: {PROJECT_START.strftime('%B %d, %Y')}  |  Generated: {date.today().strftime('%B %d, %Y')}  |  Classification: CUI  |  Version: 1.0"
    ws["A2"].font = SUBTITLE_FONT
    ws["A2"].alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 20

    ws.merge_cells("A3:T3")
    ws["A3"] = ""
    ws.row_dimensions[3].height = 6

    # ── Header Row ─────────────────────────────────────────────────
    header_row = 4
    for ci, (col_name, col_width) in enumerate(COLUMNS, 1):
        cell = ws.cell(row=header_row, column=ci, value=col_name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = col_width

    ws.row_dimensions[header_row].height = 36

    # ── Data Validation for Status Column ──────────────────────────
    status_dv = DataValidation(
        type="list",
        formula1='"Not Started,In Progress,On Hold,Blocked,Complete,Cancelled,N/A"',
        allow_blank=True,
    )
    status_dv.error = "Please select a valid status."
    status_dv.errorTitle = "Invalid Status"
    ws.add_data_validation(status_dv)

    # ── Priority Validation ────────────────────────────────────────
    priority_dv = DataValidation(
        type="list",
        formula1='"Critical,High,Medium,Low"',
        allow_blank=True,
    )
    ws.add_data_validation(priority_dv)

    # ── Populate Rows ──────────────────────────────────────────────
    tasks = build_task_list()
    data_start = header_row + 1
    row_idx = data_start
    task_counter = 0

    for (wbs, phase, name, desc, deliverable, deps, nist, priority, start_bd, dur, row_type) in tasks:
        task_counter += 1
        s_date, e_date, duration = week_range(start_bd, dur)

        # Determine display values
        if row_type == "phase" or row_type == "app_phase":
            display_name = phase
            display_desc = ""
            display_deliv = ""
        elif row_type == "milestone":
            display_name = name
            display_desc = desc
            display_deliv = deliverable
            duration = 0
            e_date = s_date
        else:
            display_name = name
            display_desc = desc
            display_deliv = deliverable

        values = [
            wbs,                                  # WBS
            phase if row_type not in ("phase", "app_phase") else "",  # Phase
            display_name,                         # Task Name
            display_desc,                         # Description
            display_deliv,                        # Deliverable
            deps,                                 # Dependencies
            nist,                                 # NIST Controls
            priority,                             # Priority
            s_date,                               # Start Date
            e_date if dur > 0 else s_date,        # End Date
            duration if dur > 0 else 0,           # Duration
            0,                                    # % Complete
            "Not Started",                        # Status
            "",                                   # Owner
            "",                                   # RACI-R
            "",                                   # RACI-A
            "",                                   # RACI-C
            "",                                   # RACI-I
            "",                                   # Risk/Blocker
            "",                                   # Comments
        ]

        for ci, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=ci, value=val)
            cell.border = THIN_BORDER
            cell.alignment = WRAP if ci in (3, 4, 5, 6, 7, 19, 20) else CENTER if ci in (1, 8, 11, 12, 13) else LEFT

            # Date formatting
            if ci in (9, 10) and isinstance(val, date):
                cell.number_format = "MMM DD, YYYY"
                cell.alignment = CENTER

            # Percentage formatting
            if ci == 12:
                cell.number_format = "0%"

        # ── Row Styling by Type ────────────────────────────────────
        if row_type == "phase":
            for ci in range(1, len(COLUMNS) + 1):
                ws.cell(row=row_idx, column=ci).fill = PHASE_FILL
                ws.cell(row=row_idx, column=ci).font = PHASE_FONT
            ws.row_dimensions[row_idx].height = 28
            # For phase rows, put the phase title in Task Name column
            ws.cell(row=row_idx, column=3).value = phase
            ws.cell(row=row_idx, column=2).value = ""

        elif row_type == "app_phase":
            for ci in range(1, len(COLUMNS) + 1):
                ws.cell(row=row_idx, column=ci).fill = APP_FILL
                ws.cell(row=row_idx, column=ci).font = PHASE_FONT
            ws.row_dimensions[row_idx].height = 28
            ws.cell(row=row_idx, column=3).value = phase
            ws.cell(row=row_idx, column=2).value = ""

        elif row_type == "milestone":
            for ci in range(1, len(COLUMNS) + 1):
                ws.cell(row=row_idx, column=ci).fill = MILESTONE_FILL
                ws.cell(row=row_idx, column=ci).font = Font(name="Calibri", bold=True, size=10, color="375623")
            ws.row_dimensions[row_idx].height = 22

        else:
            font = TASK_FONT if row_type == "task" else SUBTASK_FONT
            for ci in range(1, len(COLUMNS) + 1):
                ws.cell(row=row_idx, column=ci).font = font
            if task_counter % 2 == 0:
                for ci in range(1, len(COLUMNS) + 1):
                    if ws.cell(row=row_idx, column=ci).fill == PatternFill():
                        ws.cell(row=row_idx, column=ci).fill = ALT_ROW_FILL
            ws.row_dimensions[row_idx].height = 38

        # Apply data validation to status cell
        status_dv.add(ws.cell(row=row_idx, column=13))
        priority_dv.add(ws.cell(row=row_idx, column=8))

        row_idx += 1

    # ── Freeze Panes ───────────────────────────────────────────────
    ws.freeze_panes = f"D{data_start}"

    # ── Auto Filter ────────────────────────────────────────────────
    ws.auto_filter.ref = f"A{header_row}:{get_column_letter(len(COLUMNS))}{row_idx - 1}"

    # ── Print Setup ────────────────────────────────────────────────
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0

    # ═══════════════════════════════════════════════════════════════
    # SHEET 2: Summary Dashboard
    # ═══════════════════════════════════════════════════════════════
    ws2 = wb.create_sheet("Summary Dashboard")

    ws2.merge_cells("A1:F1")
    ws2["A1"] = "Phase Summary"
    ws2["A1"].font = TITLE_FONT
    ws2.row_dimensions[1].height = 30

    summary_headers = ["Phase", "Description", "Total Tasks", "Target Start", "Target End", "Key NIST Controls"]
    for ci, h in enumerate(summary_headers, 1):
        cell = ws2.cell(row=3, column=ci, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER

    ws2.column_dimensions["A"].width = 12
    ws2.column_dimensions["B"].width = 45
    ws2.column_dimensions["C"].width = 14
    ws2.column_dimensions["D"].width = 16
    ws2.column_dimensions["E"].width = 16
    ws2.column_dimensions["F"].width = 40

    summary_data = [
        ("Phase 0", "Project Initiation & Prerequisites", 14, 0, 9, "IA-2, AC-2, RA-2, CM-2, PM-1"),
        ("Phase 1", "Management Group Hierarchy", 5, 10, 15, "AC-1, AU-1, PM-9"),
        ("Phase 2", "Platform Subscriptions & Resource Groups", 10, 15, 22, "CM-8, CM-3"),
        ("Phase 3", "Hub-Spoke Networking", 13, 22, 37, "SC-7, AC-4, SC-5, AC-17"),
        ("Phase 4", "Centralized Logging & Monitoring", 12, 32, 46, "AU-2–AU-12, SI-4, IR-4"),
        ("Phase 5", "Identity & Access Management", 10, 37, 50, "AC-2–AC-6, IA-2–IA-5"),
        ("Phase 6", "Azure Policy – NIST 800-53 Rev 5", 11, 45, 58, "All 20 families"),
        ("Phase 7", "Encryption & Data Protection", 8, 52, 60, "SC-8, SC-12, SC-13, SC-28"),
        ("Phase 8", "Landing Zone Subscription Vending", 6, 55, 67, "AC-4, SC-7, AU-12, CM-8"),
        ("Phase 9", "Backup & Disaster Recovery", 7, 60, 72, "CP-2, CP-7, CP-9, CP-10"),
        ("Phase 10", "Application Infrastructure & Deployments (7 apps)", 7 * 16, 67, 67 + 7*10 + 22, "SA-3, CM-3, SC-7, RA-5"),
        ("Phase 11", "Compliance Validation & Audit Prep", 8, 0, 0, "CA-2, CA-5, CA-6, CA-7, CA-8"),
        ("Phase 12", "Project Closeout", 5, 0, 0, "PM-14, PL-2, AT-3, CA-7"),
    ]

    for ri, (phase, desc, count, s, e, controls) in enumerate(summary_data, 4):
        ws2.cell(row=ri, column=1, value=phase).border = THIN_BORDER
        ws2.cell(row=ri, column=2, value=desc).border = THIN_BORDER
        ws2.cell(row=ri, column=3, value=count).border = THIN_BORDER
        ws2.cell(row=ri, column=3).alignment = CENTER
        if s > 0:
            ws2.cell(row=ri, column=4, value=d(s)).border = THIN_BORDER
            ws2.cell(row=ri, column=4).number_format = "MMM DD, YYYY"
        else:
            ws2.cell(row=ri, column=4, value="See plan").border = THIN_BORDER
        if e > 0:
            ws2.cell(row=ri, column=5, value=d(e)).border = THIN_BORDER
            ws2.cell(row=ri, column=5).number_format = "MMM DD, YYYY"
        else:
            ws2.cell(row=ri, column=5, value="See plan").border = THIN_BORDER
        ws2.cell(row=ri, column=6, value=controls).border = THIN_BORDER
        ws2.cell(row=ri, column=6).alignment = WRAP

        if ri % 2 == 0:
            for ci in range(1, 7):
                ws2.cell(row=ri, column=ci).fill = ALT_ROW_FILL

    ws2.freeze_panes = "A4"

    # ═══════════════════════════════════════════════════════════════
    # SHEET 3: Application Matrix
    # ═══════════════════════════════════════════════════════════════
    ws3 = wb.create_sheet("Application Matrix")

    ws3.merge_cells("A1:H1")
    ws3["A1"] = "Application Infrastructure Deployment Matrix"
    ws3["A1"].font = TITLE_FONT
    ws3.row_dimensions[1].height = 30

    app_headers = ["#", "Application Name", "Description", "Resource Group", "Estimated Start", "Estimated Go-Live", "Environment", "Status"]
    for ci, h in enumerate(app_headers, 1):
        cell = ws3.cell(row=3, column=ci, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER

    ws3.column_dimensions["A"].width = 5
    ws3.column_dimensions["B"].width = 42
    ws3.column_dimensions["C"].width = 52
    ws3.column_dimensions["D"].width = 38
    ws3.column_dimensions["E"].width = 16
    ws3.column_dimensions["F"].width = 16
    ws3.column_dimensions["G"].width = 14
    ws3.column_dimensions["H"].width = 14

    app_start_bdays = 67
    for i, (app_name, app_desc) in enumerate(APPLICATIONS, 1):
        ri = i + 3
        app_short = app_name.split(" - ")[0].split(" –")[0].strip().lower().replace(" ", "-")
        est_start = d(app_start_bdays + (i - 1) * 10)
        est_golive = d(app_start_bdays + (i - 1) * 10 + 19)

        ws3.cell(row=ri, column=1, value=i).border = THIN_BORDER
        ws3.cell(row=ri, column=1).alignment = CENTER
        ws3.cell(row=ri, column=2, value=app_name).border = THIN_BORDER
        ws3.cell(row=ri, column=2).font = Font(name="Calibri", bold=True, size=10)
        ws3.cell(row=ri, column=3, value=app_desc).border = THIN_BORDER
        ws3.cell(row=ri, column=3).alignment = WRAP
        ws3.cell(row=ri, column=4, value=f"rg-{app_short}").border = THIN_BORDER
        ws3.cell(row=ri, column=5, value=est_start).border = THIN_BORDER
        ws3.cell(row=ri, column=5).number_format = "MMM DD, YYYY"
        ws3.cell(row=ri, column=5).alignment = CENTER
        ws3.cell(row=ri, column=6, value=est_golive).border = THIN_BORDER
        ws3.cell(row=ri, column=6).number_format = "MMM DD, YYYY"
        ws3.cell(row=ri, column=6).alignment = CENTER
        ws3.cell(row=ri, column=7, value="Production").border = THIN_BORDER
        ws3.cell(row=ri, column=7).alignment = CENTER
        ws3.cell(row=ri, column=8, value="Not Started").border = THIN_BORDER
        ws3.cell(row=ri, column=8).alignment = CENTER

        if i % 2 == 0:
            for ci in range(1, 9):
                ws3.cell(row=ri, column=ci).fill = ALT_ROW_FILL

    ws3.freeze_panes = "A4"

    # ═══════════════════════════════════════════════════════════════
    # SHEET 4: Risk Register
    # ═══════════════════════════════════════════════════════════════
    ws4 = wb.create_sheet("Risk Register")

    ws4.merge_cells("A1:J1")
    ws4["A1"] = "Project Risk Register"
    ws4["A1"].font = TITLE_FONT
    ws4.row_dimensions[1].height = 30

    risk_headers = ["Risk ID", "Category", "Risk Description", "Probability", "Impact", "Risk Score", "Mitigation Strategy", "Owner", "Status", "Last Updated"]
    for ci, h in enumerate(risk_headers, 1):
        cell = ws4.cell(row=3, column=ci, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER

    ws4.column_dimensions["A"].width = 10
    ws4.column_dimensions["B"].width = 18
    ws4.column_dimensions["C"].width = 55
    ws4.column_dimensions["D"].width = 13
    ws4.column_dimensions["E"].width = 10
    ws4.column_dimensions["F"].width = 12
    ws4.column_dimensions["G"].width = 50
    ws4.column_dimensions["H"].width = 20
    ws4.column_dimensions["I"].width = 14
    ws4.column_dimensions["J"].width = 15

    risks = [
        ("R-001", "Technical", "Entra ID P2 license procurement delayed, blocking MFA and PIM", "Medium", "High", "High", "Initiate procurement in Week 0; escalate via CIO if delayed >3 days", "", "Open", ""),
        ("R-002", "Technical", "Azure subscription limits or quota restrictions for required services", "Low", "High", "Medium", "Pre-validate quotas; submit increase requests before Phase 2", "", "Open", ""),
        ("R-003", "Organizational", "Insufficient staff bandwidth across concurrent phases", "High", "High", "Critical", "Phase overlap minimized; identify backup resources per RACI", "", "Open", ""),
        ("R-004", "Technical", "Bicep template failures or breaking changes in Azure API", "Medium", "Medium", "Medium", "Pin API versions in Bicep; maintain staging environment for validation", "", "Open", ""),
        ("R-005", "Compliance", "NIST 800-53 policy initiative creates false positives / excessive deny", "Medium", "High", "High", "Deploy in Audit mode first; establish exemption process (Phase 6.9)", "", "Open", ""),
        ("R-006", "Technical", "Network connectivity issues between Hub and Spokes", "Low", "High", "Medium", "Deploy connectivity in stages; comprehensive test plan (Phase 3.12)", "", "Open", ""),
        ("R-007", "Organizational", "Application teams not ready for landing zone onboarding", "High", "Medium", "High", "Engage app teams in Phase 0; stagger onboarding schedule", "", "Open", ""),
        ("R-008", "Security", "Break-glass account compromise", "Low", "Critical", "High", "Store credentials in physical safe; Sentinel alerts on break-glass usage", "", "Open", ""),
        ("R-009", "Schedule", "DR failover test reveals critical gaps requiring rearchitecture", "Medium", "High", "High", "Early ASR setup (Phase 9); allocate 1-week buffer for remediation", "", "Open", ""),
        ("R-010", "Compliance", "Third-party pen test identifies critical vulnerabilities pre-ATO", "Medium", "High", "High", "Continuous Defender scans during build; remediation sprint buffer in Phase 11", "", "Open", ""),
    ]

    for ri, (rid, cat, desc, prob, impact, score, mitigation, owner, status, updated) in enumerate(risks, 4):
        vals = [rid, cat, desc, prob, impact, score, mitigation, owner, status, updated]
        for ci, v in enumerate(vals, 1):
            cell = ws4.cell(row=ri, column=ci, value=v)
            cell.border = THIN_BORDER
            cell.alignment = WRAP if ci in (3, 7) else CENTER
            cell.font = TASK_FONT
        if ri % 2 == 0:
            for ci in range(1, 11):
                ws4.cell(row=ri, column=ci).fill = ALT_ROW_FILL

    ws4.freeze_panes = "A4"

    # ── Save ───────────────────────────────────────────────────────
    wb.save(OUTPUT_FILE)
    print(f"✅ Project plan generated: {OUTPUT_FILE}")
    print(f"   Total tasks: {task_counter}")
    print(f"   Sheets: Project Plan, Summary Dashboard, Application Matrix, Risk Register")


if __name__ == "__main__":
    generate_workbook()
