#!/usr/bin/env bash
# =============================================================
# deploy-phase.sh
# Deploy a single phase by name.
# Usage: ./deploy-phase.sh <phase-name>
#   phase-name: mgmt-groups | rgs | networking | logging | policy
# =============================================================
set -euo pipefail

PHASE="${1:?Usage: deploy-phase.sh <mgmt-groups|rgs|networking|logging|policy>}"
LOCATION="${LOCATION:-eastus}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INFRA_DIR="${SCRIPT_DIR}/../infra"

case "$PHASE" in
  mgmt-groups)
    echo "Deploying management group hierarchy..."
    az deployment tenant create \
      --name "nist-mgmt-groups-$(date +%Y%m%d%H%M)" \
      --location "$LOCATION" \
      --template-file "${INFRA_DIR}/01-management-groups/main.bicep" \
      --parameters prefix="${CORP_MG_NAME:-corp}"
    ;;

  rgs)
    echo "Deploying resource groups..."
    for sub_file in connectivity management identity; do
      SUB_VAR="$(echo "${sub_file}" | tr '[:lower:]' '[:upper:]')_SUB_ID"
      SUB_ID="${!SUB_VAR:?Set ${SUB_VAR}}"
      az account set --subscription "$SUB_ID"
      az stack sub create \
        --name "nist-${sub_file}-rgs" \
        --location "$LOCATION" \
        --template-file "${INFRA_DIR}/02-subscriptions/${sub_file}-rgs.bicep" \
        --deny-settings-mode denyDelete \
        --action-on-unmanage detachAll \
        --yes
    done
    ;;

  networking)
    echo "Deploying hub networking..."
    az account set --subscription "${CONNECTIVITY_SUB_ID:?Set CONNECTIVITY_SUB_ID}"
    LAW_ID="${LOG_ANALYTICS_WORKSPACE_ID:?Set LOG_ANALYTICS_WORKSPACE_ID}"
    az stack group create \
      --name "nist-hub-networking" \
      --resource-group "rg-conn-hub" \
      --template-file "${INFRA_DIR}/03-networking/main.bicep" \
      --parameters logAnalyticsWorkspaceId="$LAW_ID" \
      --deny-settings-mode denyWriteAndDelete \
      --action-on-unmanage detachAll \
      --yes
    ;;

  logging)
    echo "Deploying central logging..."
    az account set --subscription "${MANAGEMENT_SUB_ID:?Set MANAGEMENT_SUB_ID}"
    az stack group create \
      --name "nist-logging" \
      --resource-group "rg-mgmt-logging" \
      --template-file "${INFRA_DIR}/04-logging/main.bicep" \
      --parameters managementSubscriptionId="$MANAGEMENT_SUB_ID" \
      --deny-settings-mode denyWriteAndDelete \
      --action-on-unmanage detachAll \
      --yes
    ;;

  policy)
    echo "Deploying NIST 800-53 policy assignments..."
    CORP_MG="${CORP_MG_NAME:-corp}"
    az stack mg create \
      --name "nist-policy-corp" \
      --management-group-id "$CORP_MG" \
      --location "$LOCATION" \
      --template-file "${INFRA_DIR}/06-policy/main.bicep" \
      --parameters targetMgId="$CORP_MG" \
      --deny-settings-mode denyDelete \
      --action-on-unmanage detachAll \
      --yes
    ;;

  *)
    echo "Unknown phase: $PHASE"
    echo "Valid phases: mgmt-groups, rgs, networking, logging, policy"
    exit 1
    ;;
esac

echo "Phase '$PHASE' deployed successfully."
