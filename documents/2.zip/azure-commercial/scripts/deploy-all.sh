#!/usr/bin/env bash
# =============================================================
# deploy-all.sh
# Deploys all NIST 800-53 foundation infrastructure phases
# using Deployment Stacks.
#
# Prerequisites:
#   - az cli logged in with tenant-level Owner permissions
#   - Bicep CLI installed (az bicep install)
#   - Subscription IDs set in environment variables
# =============================================================
set -euo pipefail

# ---------- Configuration ----------
export LOCATION="${LOCATION:-eastus}"
export CONNECTIVITY_SUB_ID="${CONNECTIVITY_SUB_ID:?Set CONNECTIVITY_SUB_ID}"
export MANAGEMENT_SUB_ID="${MANAGEMENT_SUB_ID:?Set MANAGEMENT_SUB_ID}"
export IDENTITY_SUB_ID="${IDENTITY_SUB_ID:?Set IDENTITY_SUB_ID}"
export CORP_MG_NAME="${CORP_MG_NAME:-corp}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INFRA_DIR="${SCRIPT_DIR}/../infra"

echo "===== Phase 1: Management Groups ====="
az deployment tenant create \
  --name "nist-mgmt-groups-$(date +%Y%m%d%H%M)" \
  --location "$LOCATION" \
  --template-file "${INFRA_DIR}/01-management-groups/main.bicep" \
  --parameters prefix="$CORP_MG_NAME"

echo "===== Phase 2a: Connectivity RGs ====="
az account set --subscription "$CONNECTIVITY_SUB_ID"
az stack sub create \
  --name "nist-connectivity-rgs" \
  --location "$LOCATION" \
  --template-file "${INFRA_DIR}/02-subscriptions/connectivity-rgs.bicep" \
  --deny-settings-mode denyDelete \
  --action-on-unmanage detachAll \
  --yes

echo "===== Phase 2b: Management RGs ====="
az account set --subscription "$MANAGEMENT_SUB_ID"
az stack sub create \
  --name "nist-management-rgs" \
  --location "$LOCATION" \
  --template-file "${INFRA_DIR}/02-subscriptions/management-rgs.bicep" \
  --deny-settings-mode denyDelete \
  --action-on-unmanage detachAll \
  --yes

echo "===== Phase 2c: Identity RGs ====="
az account set --subscription "$IDENTITY_SUB_ID"
az stack sub create \
  --name "nist-identity-rgs" \
  --location "$LOCATION" \
  --template-file "${INFRA_DIR}/02-subscriptions/identity-rgs.bicep" \
  --deny-settings-mode denyDelete \
  --action-on-unmanage detachAll \
  --yes

echo "===== Phase 4: Central Logging ====="
az account set --subscription "$MANAGEMENT_SUB_ID"
az stack group create \
  --name "nist-logging" \
  --resource-group "rg-mgmt-logging" \
  --template-file "${INFRA_DIR}/04-logging/main.bicep" \
  --parameters managementSubscriptionId="$MANAGEMENT_SUB_ID" \
  --deny-settings-mode denyWriteAndDelete \
  --action-on-unmanage detachAll \
  --yes

# Capture Log Analytics Workspace ID for downstream deployments
LAW_ID=$(az monitor log-analytics workspace show \
  --resource-group rg-mgmt-logging \
  --workspace-name law-nist-central \
  --query id -o tsv)

echo "===== Phase 3: Hub Networking ====="
az account set --subscription "$CONNECTIVITY_SUB_ID"
az stack group create \
  --name "nist-hub-networking" \
  --resource-group "rg-conn-hub" \
  --template-file "${INFRA_DIR}/03-networking/main.bicep" \
  --parameters logAnalyticsWorkspaceId="$LAW_ID" \
  --deny-settings-mode denyWriteAndDelete \
  --action-on-unmanage detachAll \
  --yes

echo "===== Phase 6: NIST Policy Assignments ====="
az stack mg create \
  --name "nist-policy-corp" \
  --management-group-id "$CORP_MG_NAME" \
  --location "$LOCATION" \
  --template-file "${INFRA_DIR}/06-policy/main.bicep" \
  --parameters targetMgId="$CORP_MG_NAME" \
  --deny-settings-mode denyDelete \
  --action-on-unmanage detachAll \
  --yes

echo ""
echo "===== Deployment Complete ====="
echo "Next steps:"
echo "  1. Configure Entra ID Conditional Access and PIM (Phase 5 -- manual)"
echo "  2. Deploy spoke networks for landing zone subscriptions (Phase 8)"
echo "  3. Enable Microsoft Defender for Cloud plans"
echo "  4. Validate compliance in Defender for Cloud regulatory compliance dashboard"
